from __future__ import annotations
from pydantic import BaseModel
import os
from pathlib import Path
from dotenv import load_dotenv

ENV_PATH = Path("/opt/vk_checker/v4/.env")
load_dotenv(dotenv_path=ENV_PATH, override=True)

class AppSettings(BaseModel):
    users_root: Path = Path(os.getenv("VK_CHECKER_USERS_ROOT", "/opt/vk_checker/v4/users"))

    tg_bot_token: str = os.getenv("TG_BOT_TOKEN", "").strip()
    tg_bot_tokens: list[str] = [t.strip() for t in os.getenv("TG_BOT_TOKENS","").split(",") if t.strip()] \
        or ([os.getenv("TG_BOT_TOKEN","").strip()] if os.getenv("TG_BOT_TOKEN","").strip() else [])

    jwt_secret: str = os.getenv("VK_CHECKER_JWT_SECRET", "change-me-in-env").strip()
    jwt_ttl_seconds: int = int(os.getenv("VK_CHECKER_JWT_TTL_SECONDS", "3600"))

    vk_api_base: str = os.getenv("VK_API_BASE", "https://ads.vk.com").strip()
    cors_allow_origins: list[str] = os.getenv("VK_CHECKER_CORS_ORIGINS", "").split(",") if os.getenv("VK_CHECKER_CORS_ORIGINS") else []

settings = AppSettings()
