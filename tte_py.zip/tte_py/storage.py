from __future__ import annotations
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any
import fcntl
import time
import uuid

from .models import UserFile, FiltersFile, SettingsFile, AccountItem, ListFile
from .settings import settings

SUB1_MAP = {
    "krolik": "/opt/leads_postback/data/krolik.json",
    "insta": "/opt/leads_postback/data/insta.json",
    "zarplatkinrf": "/opt/leads_postback/data/zarplatkinrf.json",
    "nalickinrf": "/opt/leads_postback/data/nalickinrf.json",
    "karakoz_karas": "/opt/leads_postback/data/karakoz_karas.json",
    "utkavalutkarf": "/opt/leads_postback/data/utkavalutkarf.json",
    "vydavayka": "/opt/leads_postback/data/vydavayka.json",
    "1russ": "/opt/leads_postback/data/1russ.json",
}

def set_income_path(tg_id: str, sub1_key: str) -> UserFile:
    if sub1_key not in SUB1_MAP:
        raise ValueError("unknown sub1")

    uf = get_user_file(tg_id)
    uf.income_path = SUB1_MAP[sub1_key]
    save_user_file(tg_id, uf)
    return uf

def _user_dir(tg_id: str) -> Path:
    return settings.users_root / str(tg_id)

def _user_json_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / f"{tg_id}.json"

def _filters_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / "filters.json"

def _white_list_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / "white_list.json"

def _black_list_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / "black_list.json"

def _settings_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / "settings.json"

def _env_path(tg_id: str) -> Path:
    return _user_dir(tg_id) / ".env"

def _atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        os.chmod(path, 0o600)
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

def _read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def ensure_user_files(tg_id: str, tg_username: str) -> None:
    udir = _user_dir(tg_id)
    udir.mkdir(parents=True, exist_ok=True)
    os.chmod(udir, 0o700)

    # user file
    up = _user_json_path(tg_id)
    if not up.exists():
        _atomic_write_json(up, UserFile(tg_id=str(tg_id), tg_username=tg_username, accounts=[]).model_dump())

    # filters
    fp = _filters_path(tg_id)
    if not fp.exists():
        _atomic_write_json(fp, default_filters_file().model_dump())

    # settings
    sp = _settings_path(tg_id)
    if not sp.exists():
        _atomic_write_json(sp, SettingsFile().model_dump())

def _tpl_id() -> str:
    return f"tpl_{uuid.uuid4().hex[:12]}_{int(time.time() * 1000)}"

def default_filters_file() -> FiltersFile:
    return FiltersFile(
        version=1,
        templates=[
            {
                "id": _tpl_id(),
                "name": "Доходные",
                "priority": 1,
                "root": {
                    "type": "ROOT",
                    "accountsScope": {"mode": "ALL", "selected": None},
                    "conditions": [
                        {
                            "type": "SPENT",
                            "period": {"type": "LAST_N_DAYS", "n": 2},
                            "op": "GTE",
                            "valueRub": 100.0,
                        },
                        {
                            "type": "INCOME",
                            "period": {"type": "LAST_N_DAYS", "n": 2},
                            "mode": "HAS",
                            "op": None,
                            "value": None,
                            "multiplier": None,
                            "spendPeriod": None,
                        },
                    ],
                    "child": {
                        "type": "FILTER",
                        "mode": "ANY",
                        "rules": [],
                        "action": {"type": "SET_STATE", "state": "ENABLE"},
                    },
                },
            },
            {
                "id": _tpl_id(),
                "name": "Базовый фильтр",
                "priority": 3,
                "root": {
                    "type": "ROOT",
                    "accountsScope": {"mode": "ALL", "selected": None},
                    "conditions": [
                        {
                            "type": "SPENT",
                            "period": {"type": "ALL_TIME", "n": None},
                            "op": "LTE",
                            "valueRub": 2000.0,
                        },
                        {
                            "type": "INCOME",
                            "period": {"type": "LAST_N_DAYS", "n": 4},
                            "mode": "HAS_NOT",
                            "op": None,
                            "value": None,
                            "multiplier": None,
                            "spendPeriod": None,
                        },
                    ],
                    "child": {
                        "type": "FILTER",
                        "mode": "ANY",
                        "rules": [
                            {
                                "type": "COST_RULE",
                                "spentRub": 240.0,
                                "metric": "RESULTS",
                                "op": "EQ",
                                "value": 0.0,
                            },
                            {
                                "type": "COST_RULE",
                                "spentRub": 110.0,
                                "metric": "CLICKS",
                                "op": "EQ",
                                "value": 0.0,
                            },
                            {
                                "type": "COST_RULE",
                                "spentRub": 300.0,
                                "metric": "RESULT_COST",
                                "op": "GTE",
                                "value": 300.0,
                            },
                        ],
                        "action": {"type": "SET_STATE", "state": "DISABLE"},
                    },
                },
            },
        ],
    )

def get_user_file(tg_id: str) -> UserFile:
    data = _read_json(_user_json_path(tg_id), {})
    try:
        return UserFile.model_validate(data)
    except Exception:
        return UserFile(tg_id=str(tg_id), tg_username="", accounts=[])

def save_user_file(tg_id: str, uf: UserFile) -> None:
    _atomic_write_json(_user_json_path(tg_id), uf.model_dump())

def get_filters(tg_id: str) -> FiltersFile:
    data = _read_json(_filters_path(tg_id), {})
    try:
        return FiltersFile.model_validate(data)
    except Exception:
        return default_filters_file()

def save_filters(tg_id: str, ff: FiltersFile) -> None:
    _atomic_write_json(_filters_path(tg_id), ff.model_dump())

def get_settings(tg_id: str) -> SettingsFile:
    data = _read_json(_settings_path(tg_id), {})
    try:
        return SettingsFile.model_validate(data)
    except Exception:
        return SettingsFile()

def save_settings(tg_id: str, sf: SettingsFile) -> None:
    _atomic_write_json(_settings_path(tg_id), sf.model_dump())

def _with_flock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    f = open(path, "a+", encoding="utf-8")
    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
    return f

def allocate_env_token_name(tg_id: str) -> str:
    envp = _env_path(tg_id)
    with _with_flock(envp) as f:
        f.seek(0)
        content = f.read()
        nums = [int(m.group(1)) for m in re.finditer(r"^VK_TOKEN_(\d+)=", content, re.M)]
        n = (max(nums) + 1) if nums else 1
        return f"VK_TOKEN_{n}"

def append_env_token(tg_id: str, key: str, token: str) -> None:
    envp = _env_path(tg_id)
    with _with_flock(envp) as f:
        f.seek(0)
        content = f.read()
        # If key already exists, replace line; else append
        if re.search(rf"^({re.escape(key)})=", content, re.M):
            new = re.sub(rf"^({re.escape(key)})=.*$", rf"\1={token}", content, flags=re.M)
            f.seek(0)
            f.truncate()
            f.write(new.rstrip() + "\n")
        else:
            if content and not content.endswith("\n"):
                f.write("\n")
            f.write(f"{key}={token}\n")
        f.flush()
        os.fsync(f.fileno())
    os.chmod(envp, 0o600)

def add_account(tg_id: str, name: str, acc_id: str, env_key: str) -> UserFile:
    uf = get_user_file(tg_id)
    # Prevent duplicates by account id
    if any(a.id == str(acc_id) for a in uf.accounts):
        return uf
    uf.accounts.append(AccountItem(token=env_key, name=name, id=str(acc_id)))
    save_user_file(tg_id, uf)
    return uf

def get_white_list(tg_id: str) -> ListFile:
    data = _read_json(_white_list_path(tg_id), {})
    try:
        return ListFile.model_validate(data)
    except Exception:
        return ListFile()

def save_white_list(tg_id: str, lf: ListFile) -> None:
    _atomic_write_json(_white_list_path(tg_id), lf.model_dump())

def get_black_list(tg_id: str) -> ListFile:
    data = _read_json(_black_list_path(tg_id), {})
    try:
        return ListFile.model_validate(data)
    except Exception:
        return ListFile()

def save_black_list(tg_id: str, lf: ListFile) -> None:
    _atomic_write_json(_black_list_path(tg_id), lf.model_dump())