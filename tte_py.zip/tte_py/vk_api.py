from __future__ import annotations
import httpx
from fastapi import HTTPException
from .settings import settings

async def validate_vk_token(token: str) -> dict:
    '''
    Calls VK Ads-style endpoint:
      GET {VK_API_BASE}/api/v3/user.json?fields=additional_info,id
    with token.

    Different installations may expect token in header or query. We try a couple of common variants.
    '''
    url = settings.vk_api_base.rstrip("/") + "/api/v3/user.json"
    params = {"fields": "additional_info,id"}

    async with httpx.AsyncClient(timeout=15) as client:
        # Variant 1: Bearer
        r = await client.get(url, params=params, headers={"Authorization": f"Bearer {token}"})
        if r.status_code in (401, 403):
            # Variant 2: token as query parameter
            r = await client.get(url, params={**params, "access_token": token})
        if r.status_code >= 400:
            raise HTTPException(status_code=400, detail=f"VK token validation failed ({r.status_code})")
        try:
            data = r.json()
        except Exception:
            raise HTTPException(status_code=400, detail="VK token validation: invalid JSON response")

    # expected:
    # { "additional_info": {"client_name": "...", "email": "..."}, "id": 21799870 }
    additional = data.get("additional_info") or {}
    client_name = additional.get("client_name") or additional.get("name") or ""
    acc_id = data.get("id")
    if not acc_id or not client_name:
        # Still allow, but require id
        if not acc_id:
            raise HTTPException(status_code=400, detail="VK token validation: missing id")
        if not client_name:
            client_name = f"Cabinet {acc_id}"
    return {
        "id": str(acc_id),
        "client_name": str(client_name),
        "email": additional.get("email")
    }
