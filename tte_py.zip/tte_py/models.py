from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal

# ---- API payloads ----

class BootstrapIn(BaseModel):
    initData: str

class BootstrapOut(BaseModel):
    jwt: str
    user: dict

class TokenValidateIn(BaseModel):
    token: str = Field(min_length=10, max_length=4096)

class TokenValidateOut(BaseModel):
    id: str
    client_name: str
    email: str | None = None

class TokenConfirmIn(BaseModel):
    token: str = Field(min_length=10, max_length=4096)
    id: str
    name: str

class AccountItem(BaseModel):
    token: str   # like VK_TOKEN_1 (env var name)
    name: str
    id: str

class UserFile(BaseModel):
    tg_id: str
    tg_username: str = ""
    accounts: list[AccountItem] = Field(default_factory=list)
    income_path: str = ""

class UserOut(BaseModel):
    tg_id: str
    tg_username: str
    accounts: list[AccountItem]
    filters: FiltersFile
    settings: SettingsFile
    income_path: str = ""

# ---- Settings file ----
class HistorySettings(BaseModel):
    performance_mode: bool = False   # “Производительный режим (убрать превью)”
    show_disabled: bool = True       # “Показывать отключенные”
    show_enabled: bool = True        # “Показывать включенные”

class SettingsFile(BaseModel):
    # Общие
    ignore_manual_enabled_ads: bool = True

    # Безопасность
    limit_disabled_banners_20: bool = True
    only_spent_all_time_lte_5000: bool = True

    # Уведомления
    tg_notify_enabled: bool = True
    tg_notify_every_min: int = 30

    # История (у тебя уже используется во фронте)
    history_settings: HistorySettings = Field(default_factory=HistorySettings)

class ListFile(BaseModel):
    campaign_ids: list[str] = Field(default_factory=list)
    banner_ids: list[str] = Field(default_factory=list)

# ---- Filters schema (v1) ----
Op = Literal["LT","LTE","GT","GTE","EQ"]
PeriodType = Literal["ALL_TIME", "TODAY", "YESTERDAY", "LAST_N_DAYS"]

class Period(BaseModel):
    type: PeriodType
    n: int | None = None

class ConditionSpent(BaseModel):
    cid: str | None = None
    type: Literal["SPENT"] = "SPENT"
    period: Period
    op: Op
    valueRub: float

class ConditionTarget(BaseModel):
    cid: str | None = None
    type: Literal["TARGET_ACTION"] = "TARGET_ACTION"
    target: Literal["BOT_MESSAGE","SITE","LEADFORM","APP"]

class ConditionIncome(BaseModel):
    cid: str | None = None
    type: Literal["INCOME"] = "INCOME"
    period: Period
    mode: Literal["HAS", "HAS_NOT", "COMPARE", "COMPARE_SPEND"]
    op: Op | None = None
    value: float | None = None
    multiplier: float | None = None
    spendPeriod: Period | None = None

RootCondition = ConditionSpent | ConditionTarget | ConditionIncome

Metric = Literal["CLICK_COST","RESULT_COST","CLICKS","RESULTS"]
class FilterRule(BaseModel):
    type: Literal["COST_RULE"] = "COST_RULE"
    spentRub: float
    metric: Metric
    op: Op
    value: float

ActionState = Literal["ENABLE","DISABLE","NOOP"]
class Action(BaseModel):
    type: Literal["SET_STATE"] = "SET_STATE"
    state: ActionState = "NOOP"

class NestedFilter(BaseModel):
    type: Literal["FILTER"] = "FILTER"
    mode: Literal["ALL","ANY"] = "ALL"
    rules: list[FilterRule] = Field(default_factory=list)
    action: Action = Field(default_factory=Action)

class AccountsScope(BaseModel):
    mode: Literal["ALL","SELECTED"] = "ALL"
    selected: list[str] | None = None  # account ids

class RootNode(BaseModel):
    type: Literal["ROOT"] = "ROOT"
    accountsScope: AccountsScope = AccountsScope()
    conditions: list[RootCondition] = Field(default_factory=list)
    child: NestedFilter | Action

class FilterTemplate(BaseModel):
    id: str
    name: str
    priority: int | None = 3
    root: RootNode

class FiltersFile(BaseModel):
    version: int = 1
    templates: list[FilterTemplate] = Field(default_factory=list)
