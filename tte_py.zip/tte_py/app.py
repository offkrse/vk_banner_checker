from __future__ import annotations
from fastapi import FastAPI, Depends, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from pydantic import BaseModel
from datetime import datetime
from typing import Any
import os
import uuid
import json

from .settings import settings
from .models import (
    BootstrapIn, BootstrapOut,
    TokenValidateIn, TokenValidateOut,
    TokenConfirmIn,
    FiltersFile, SettingsFile, ListFile
)
from .auth import verify_init_data, issue_jwt, require_user
from .storage import (
    ensure_user_files,
    get_user_file,
    get_filters, save_filters,
    get_settings, save_settings,
    allocate_env_token_name, append_env_token, add_account,
    set_income_path,
    get_white_list, save_white_list,
    get_black_list, save_black_list,
)
from .vk_api import validate_vk_token

app = FastAPI(title="VK Checker Mini App", version="1.0.0")

if settings.cors_allow_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in settings.cors_allow_origins if o.strip()],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

class IncomePathIn(BaseModel):
    sub1: str

def _admin_ids() -> list[str]:
    admin_env = os.getenv("ADMIN_TG_IDS") or os.getenv("ADMIN_TG_ID") or "1342381428"
    return [x.strip() for x in admin_env.split(",") if x.strip()]

def _is_admin(tg_id: str) -> bool:
    return str(tg_id) in _admin_ids()

# --- API ---

@app.post("/api/bootstrap", response_model=BootstrapOut)
async def bootstrap(payload: BootstrapIn):
    init = verify_init_data(payload.initData)
    user = init.get("user") or {}
    tg_id = str(user.get("id") or "")
    if not tg_id:
        raise HTTPException(status_code=400, detail="Telegram user id not found in initData")
    tg_username = str(user.get("username") or "")

    ensure_user_files(tg_id, tg_username)
    jwt_token = issue_jwt(tg_id)

    # Return basic state so frontend can render immediately
    uf = get_user_file(tg_id)
    ff = get_filters(tg_id)
    sf = get_settings(tg_id)

    return BootstrapOut(jwt=jwt_token, user={
        "tg_id": tg_id,
        "tg_username": tg_username,
        "accounts": [a.model_dump() for a in uf.accounts],
        "filters": ff.model_dump(),
        "settings": sf.model_dump(),
        "income_path": uf.income_path,
        "is_admin": _is_admin(tg_id),
    })

@app.get("/api/state")
async def get_state(tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    uf = get_user_file(tg_id)
    ff = get_filters(tg_id)
    sf = get_settings(tg_id)
    return {
        "accounts": [a.model_dump() for a in uf.accounts],
        "filters": ff.model_dump(),
        "settings": sf.model_dump(),
        "income_path": uf.income_path,
        "is_admin": _is_admin(tg_id),
    }

@app.post("/api/accounts/validate", response_model=TokenValidateOut)
async def accounts_validate(payload: TokenValidateIn, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    data = await validate_vk_token(payload.token)
    return TokenValidateOut(id=data["id"], client_name=data["client_name"], email=data.get("email"))

@app.post("/api/accounts/confirm")
async def accounts_confirm(payload: TokenConfirmIn, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    key = allocate_env_token_name(tg_id)
    append_env_token(tg_id, key, payload.token)
    uf = add_account(tg_id, payload.name, payload.id, key)
    return {"accounts": [a.model_dump() for a in uf.accounts]}

@app.get("/api/filters")
async def api_get_filters(tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    ff = get_filters(tg_id)
    return ff.model_dump()

@app.put("/api/filters")
async def api_put_filters(payload: FiltersFile, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    save_filters(tg_id, payload)
    return {"ok": True}

@app.get("/api/settings")
async def api_get_settings(tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    sf = get_settings(tg_id)
    return sf.model_dump()

@app.put("/api/settings")
async def api_put_settings(payload: SettingsFile, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    save_settings(tg_id, payload)
    return {"ok": True}

@app.get("/api/lists/{kind}")
async def api_get_list(kind: str, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    if kind == "white":
        return get_white_list(tg_id).model_dump()
    if kind == "black":
        return get_black_list(tg_id).model_dump()
    raise HTTPException(status_code=400, detail="Unknown list kind")

@app.put("/api/lists/{kind}")
async def api_put_list(kind: str, payload: ListFile, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    if kind == "white":
        save_white_list(tg_id, payload)
        return {"ok": True}
    if kind == "black":
        save_black_list(tg_id, payload)
        return {"ok": True}
    raise HTTPException(status_code=400, detail="Unknown list kind")

@app.get("/api/history/banners")
async def api_history_banners(account_id: str, date: str, tg_id: str = Depends(require_user)):
    """
    date: YYYY-MM-DD
    """
    ensure_user_files(tg_id, "")
    p = settings.users_root / str(tg_id) / str(account_id) / "history_banners.json"
    if not p.exists():
        return {"items": []}

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return {"items": []}
    except Exception:
        return {"items": []}

    out: list[dict[str, Any]] = []
    for x in data:
        try:
            dt = datetime.strptime(str(x.get("daytime", "")), "%Y-%m-%d %H:%M:%S")
            if dt.strftime("%Y-%m-%d") == date:
                out.append(x)
        except Exception:
            continue

    out.sort(key=lambda it: it.get("daytime", ""), reverse=True)
    return {"items": out}

@app.put("/api/income-path")
async def api_set_income_path(payload: IncomePathIn, tg_id: str = Depends(require_user)):
    ensure_user_files(tg_id, "")
    try:
        uf = set_income_path(tg_id, payload.sub1)
    except ValueError:
        raise HTTPException(status_code=400, detail="Unknown sub1")

    return {"ok": True, "income_path": uf.income_path}

# --- Frontend serving (SPA) ---
# Put built files into: vk_checker/webapp/static
STATIC_DIR = Path(__file__).parent / "static"

# ---------------- Admin endpoints ----------------
def require_admin(tg_id: str = Depends(require_user)) -> str:
    # ADMIN_TG_IDS can be a comma-separated list in env, or single ADMIN_TG_ID
    admin_env = os.getenv("ADMIN_TG_IDS") or os.getenv("ADMIN_TG_ID") or "1342381428"
    admin_ids = [x.strip() for x in admin_env.split(",") if x.strip()]
    if tg_id not in admin_ids:
        raise HTTPException(status_code=403, detail="admin required")
    return tg_id

@app.get("/api/admin/users")
async def api_admin_list_users(q: str = "", admin_tg: str = Depends(require_admin)):
    # scan users root directory
    users = []
    root = Path(settings.users_root)
    if root.exists() and root.is_dir():
        for child in root.iterdir():
            if not child.is_dir():
                continue
            tgid = child.name
            try:
                uf = get_user_file(tgid)
                users.append({"tg_id": uf.tg_id, "tg_username": uf.tg_username, "accounts": [a.model_dump() if hasattr(a,'model_dump') else a for a in uf.accounts]})
            except Exception:
                # skip broken users
                continue
    # simple filtering
    ql = q.strip().lower()
    if ql:
        users = [u for u in users if ql in u["tg_id"].lower() or ql in (u.get("tg_username") or "").lower() or any(ql in (a.get("id","") or "").lower() for a in u.get("accounts",[]))]
    return {"users": users}

@app.get("/api/admin/users/{tg_id}/filters")
async def api_admin_get_user_filters(tg_id: str, admin_tg: str = Depends(require_admin)):
    ensure_user_files(tg_id, "")
    ff = get_filters(tg_id)
    return ff.model_dump()

@app.put("/api/admin/users/{tg_id}/filters")
async def api_admin_put_user_filters(tg_id: str, payload: FiltersFile, admin_tg: str = Depends(require_admin)):
    ensure_user_files(tg_id, "")
    save_filters(tg_id, payload)
    # log action
    try:
        logp = Path(settings.users_root) / "admin_actions.log"
        with open(logp, "a") as f:
            f.write(json.dumps({"at": datetime.utcnow().isoformat()+"Z", "admin": admin_tg, "action": "update_filters", "target": tg_id}) + "\n")
    except Exception:
        pass
    return {"ok": True}

@app.post("/api/admin/impersonate")
async def api_admin_impersonate(payload: dict = Body(...), admin_tg: str = Depends(require_admin)):
    tg_id = str(payload.get("tg_id") or "")
    if not tg_id:
        raise HTTPException(status_code=400, detail="tg_id required")
    # ensure user exists
    ensure_user_files(tg_id, "")
    # issue jwt for target user
    token = issue_jwt(tg_id)
    try:
        logp = Path(settings.users_root) / "admin_actions.log"
        with open(logp, "a") as f:
            f.write(json.dumps({"at": datetime.utcnow().isoformat()+"Z", "admin": admin_tg, "action": "impersonate", "target": tg_id}) + "\n")
    except Exception:
        pass
    return {"jwt": token}

if STATIC_DIR.exists():
    app.mount("/assets", StaticFiles(directory=str(STATIC_DIR / "assets")), name="assets")

    @app.get("/")
    async def spa_index():
        index = STATIC_DIR / "index.html"
        return FileResponse(index)

    @app.get("/{full_path:path}")
    async def spa_fallback(full_path: str):
        # Serve real files if exist; otherwise fallback to index.html (SPA routing)
        candidate = STATIC_DIR / full_path
        if candidate.exists() and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(STATIC_DIR / "index.html")
else:
    @app.get("/")
    async def no_static():
        return {"status": "vk_checker webapp API running", "static": False}
