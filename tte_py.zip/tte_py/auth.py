from __future__ import annotations
import json
import time
import hmac
import hashlib
import jwt
import os
import logging
import base64
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from typing import Any, Optional
from urllib.parse import parse_qsl, unquote
from fastapi import Header, HTTPException
from .settings import settings


logger = logging.getLogger("vk_checker.initdata")

TG_PUBKEY_PROD_HEX = "e7bf03a2fa4602af4580703d88dda5bb59f32ed8b02a56c187fe7d34caed242d"
TG_PUBKEY_TEST_HEX = "40055058a4ee38156a06562e52eece92a771bcd8346a8c4615cb7376eddf72ec"

def _calc_hash(init_data: str) -> tuple[str, dict[str, str], str]:
    s = init_data.strip().lstrip("?")

    pairs = dict(parse_qsl(s, keep_blank_values=True))
    recv_hash = pairs.get("hash", "")
    if not recv_hash:
        raise HTTPException(status_code=401, detail="initData hash missing")

    pairs_no_hash = {k: v for k, v in pairs.items() if k not in ("hash", "signature")}
    data_check_string = "\n".join(f"{k}={pairs_no_hash[k]}" for k in sorted(pairs_no_hash))

    # Возвращаем dcs и recv_hash — проверим по токенам выше
    return data_check_string, pairs_no_hash, recv_hash


def _dcs_decoded(init_data: str) -> tuple[str, str, dict[str, str]]:
    s = init_data.strip().lstrip("?")
    pairs = dict(parse_qsl(s, keep_blank_values=True))  # декодит %xx
    recv_hash = pairs.get("hash", "")
    if not recv_hash:
        raise HTTPException(status_code=401, detail="initData hash missing")

    pairs_no_hash = {k: v for k, v in pairs.items() if k not in ("hash", "signature")}
    dcs = "\n".join(f"{k}={pairs_no_hash[k]}" for k in sorted(pairs_no_hash))
    return dcs, recv_hash, pairs_no_hash

def _verify_signature_third_party(init_data: str) -> dict[str, Any]:
    s = init_data.strip().lstrip("?")
    pairs = dict(parse_qsl(s, keep_blank_values=True))  # URL-decode значений

    sig_b64 = pairs.get("signature")
    if not sig_b64:
        raise HTTPException(status_code=401, detail="signature missing")

    # hash в этом режиме не нужен, signature и hash исключаем из dcs
    pairs_no = {k: v for k, v in pairs.items() if k not in ("hash", "signature")}
    dcs_tail = "\n".join(f"{k}={pairs_no[k]}" for k in sorted(pairs_no.keys()))

    # bot_id = число до двоеточия в bot token
    if not settings.tg_bot_token or ":" not in settings.tg_bot_token:
        raise HTTPException(status_code=500, detail="TG_BOT_TOKEN invalid")
    bot_id = settings.tg_bot_token.split(":", 1)[0]

    # data-check-string для third-party:
    # "<bot_id>:WebAppData\n" + sorted pairs joined by \n
    data_check = f"{bot_id}:WebAppData\n{dcs_tail}".encode("utf-8")

    # Telegram часто шлёт signature без padding "=" → добавляем
    sig_pad = sig_b64 + ("=" * (-len(sig_b64) % 4))
    signature = base64.urlsafe_b64decode(sig_pad)

    pub_hex = TG_PUBKEY_PROD_HEX  # если у тебя test env — замени на TG_PUBKEY_TEST_HEX
    pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex))
    
    try:
        pub.verify(signature, data_check)  # бросит exception если неверно
    except Exception:
        raise HTTPException(status_code=401, detail="initData verification failed")

    # распарсим user как JSON (как раньше)
    if "user" in pairs:
        try:
            pairs["user"] = json.loads(pairs["user"])
        except Exception:
            pass

    return pairs

def verify_init_data(init_data: str) -> dict[str, Any]:
    if not settings.tg_bot_token:
        raise HTTPException(status_code=500, detail="TG_BOT_TOKEN is not configured")

    try:
        s = init_data.strip().lstrip("?")
        pairs0 = dict(parse_qsl(s, keep_blank_values=True))
        if "signature" in pairs0 and pairs0["signature"]:
            return _verify_signature_third_party(init_data)
    except HTTPException:
        raise
    except Exception as e:
        # если крипта/парсинг упали — пусть дальше пойдёт HMAC (или вернём 401 ниже)
        logger.warning("signature verification exception: %r", e)

    s = init_data.strip().lstrip("?")

    # ВАЖНО: parse_qsl декодирует %xx (как и нужно)
    pairs = dict(parse_qsl(s, keep_blank_values=True))

    recv_hash = pairs.pop("hash", "")
    if not recv_hash:
        raise HTTPException(status_code=401, detail="initData hash missing")

    # signature НЕ включаем (иначе подпись будет не совпадать)
    pairs.pop("signature", None)

    data_check_string = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))

    # ✅ ОФИЦИАЛЬНО: secret_key = HMAC_SHA256(<bot_token>, "WebAppData")
    secret_key = hmac.new(
        settings.tg_bot_token.encode("utf-8"),
        b"WebAppData",
        hashlib.sha256,
    ).digest()

    calc_hash = hmac.new(
        secret_key,
        data_check_string.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(calc_hash, recv_hash):
        raise HTTPException(status_code=401, detail="initData verification failed")

    # auth_date check
    try:
        auth_date = int(pairs.get("auth_date", "0"))
        if auth_date and (time.time() - auth_date) > 24 * 3600:
            raise HTTPException(status_code=401, detail="initData expired")
    except ValueError:
        pass

    # parse user JSON (после проверки!)
    if "user" in pairs:
        try:
            pairs["user"] = json.loads(pairs["user"])
        except Exception:
            pass

    return pairs

def issue_jwt(tg_id: str) -> str:
    now = int(time.time())
    payload = {
        "sub": str(tg_id),
        "iat": now,
        "exp": now + settings.jwt_ttl_seconds,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def require_user(authorization: Optional[str] = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        tg_id = str(payload.get("sub", ""))
        if not tg_id:
            raise HTTPException(status_code=401, detail="Invalid token payload")
        return tg_id
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")
