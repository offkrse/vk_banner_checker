import React, { useMemo, useState } from "react"
import { motion } from "framer-motion"
import type { SettingsFile } from "../lib/types"

type SettingsSubTab = "general" | "security" | "notifications"

const subTabs: { key: SettingsSubTab; label: string }[] = [
  { key: "general", label: "Общие" },
  { key: "security", label: "Безопасность" },
  { key: "notifications", label: "Уведомления" },
]

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n))
}

function formatEveryMin(min: number) {
  const m = Math.max(30, min || 30)
  if (m < 60) return `${m} мин`
  const h = Math.floor(m / 60)
  const mm = m % 60
  if (mm === 0) return `${h} час`
  return `${h} ч ${mm} мин`
}

export function SettingsTab({
  value,
  onChange,
  onRestoreBaseFilters,
}: {
  value: SettingsFile
  onChange: (v: SettingsFile) => void
  onRestoreBaseFilters: () => void
}) {
  const [subTab, setSubTab] = useState<SettingsSubTab>("general")

  // дефолты, чтобы UI не ломался если поле отсутствует
  const v = useMemo(
    () => ({
      ignore_manual_enabled_ads: value.ignore_manual_enabled_ads ?? true,

      limit_disabled_banners_20: value.limit_disabled_banners_20 ?? false,
      only_spent_all_time_lte_5000: value.only_spent_all_time_lte_5000 ?? false,

      tg_notify_enabled: value.tg_notify_enabled ?? true,
      tg_notify_every_min: value.tg_notify_every_min ?? 30,
    }),
    [value]
  )

  const patch = (p: Partial<SettingsFile>) => onChange({ ...value, ...p })

  return (
    <div className="px-3 pb-24 pt-3">
      {/* внутренний бар (как табы сверху), на всю ширину */}
      <div className="sticky top-[55px] z-20 -mx-3 -mt-3">
        <div className="glass border border-white/10">
          <div className="flex overflow-x-auto no-scrollbar">
            {subTabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setSubTab(t.key)}
                className="relative flex-1 px-3 py-3 text-sm font-medium text-white/80"
              >
                <span className={subTab === t.key ? "text-white" : ""}>
                  {t.label}
                </span>

                {subTab === t.key && (
                  <motion.div
                    layoutId="settings-subtab-underline"
                    className="absolute left-3 right-3 bottom-1 h-1 rounded-full bg-white/70"
                    transition={{ type: "spring", stiffness: 500, damping: 36 }}
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* контент */}
      <div className="mt-3 space-y-3">
        {subTab === "general" && (
          <div className="space-y-3">
            <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
              <div className="text-sm">
                <div className="font-medium">
                  Не трогать объявления, которые включены вручную
                </div>
                <div className="text-xs text-white/50">
                  По умолчанию включено
                </div>
              </div>

              <input
                type="checkbox"
                checked={v.ignore_manual_enabled_ads}
                onChange={(e) =>
                  patch({ ignore_manual_enabled_ads: e.target.checked })
                }
              />
            </label>
              
            <button
              onClick={onRestoreBaseFilters}
              className="w-full text-center rounded-2xl bg-white/5 px-3 py-3 hover:bg-white/10 active:bg-white/15"
            >
              <div className="font-medium">Восстановить базовые фильтры</div>
            </button>
          </div>
        )}

        {subTab === "security" && (
          <>
            <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
              <div className="text-sm">
                <div className="font-medium">
                  Ограничить кол-во отключенных баннеров за раз до 20
                </div>
              </div>

              <input
                type="checkbox"
                checked={v.limit_disabled_banners_20}
                onChange={(e) =>
                  patch({ limit_disabled_banners_20: e.target.checked })
                }
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
              <div className="text-sm">
                <div className="font-medium">
                  Отключать только баннеры, у которых потрачено за всё время до
                  5000₽
                </div>
                <div className="text-xs text-white/50">
                  Если включено - баннеры с расходом выше 5000₽ не отключаются
                </div>
              </div>

              <input
                type="checkbox"
                checked={v.only_spent_all_time_lte_5000}
                onChange={(e) =>
                  patch({ only_spent_all_time_lte_5000: e.target.checked })
                }
              />
            </label>
          </>
        )}

        {subTab === "notifications" && (
          <>
            <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
              <div className="text-sm">
                <div className="font-medium">Отправлять уведомления в тг</div>
              </div>

              <input
                type="checkbox"
                checked={v.tg_notify_enabled}
                onChange={(e) => patch({ tg_notify_enabled: e.target.checked })}
              />
            </label>

            {v.tg_notify_enabled && (
              <div className="rounded-2xl bg-white/5 px-3 py-3">
                <div className="text-sm font-medium mb-2">
                  Отправлять уведомления раз в:
                </div>

                <div className="flex items-center justify-between gap-2">
                  <button
                    className="rounded-2xl chip px-3 py-2"
                    onClick={() => {
                      const next = clamp((v.tg_notify_every_min ?? 30) - 30, 30, 1440)
                      patch({ tg_notify_every_min: next })
                    }}
                    aria-label="Минус 30 минут"
                  >
                    −
                  </button>

                  <div className="rounded-2xl bg-white/5 px-4 py-2 text-sm text-white/80">
                    {formatEveryMin(v.tg_notify_every_min ?? 30)}
                  </div>

                  <button
                    className="rounded-2xl chip px-3 py-2"
                    onClick={() => {
                      const next = clamp((v.tg_notify_every_min ?? 30) + 30, 30, 1440)
                      patch({ tg_notify_every_min: next })
                    }}
                    aria-label="Плюс 30 минут"
                  >
                    +
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}