import React from 'react'
import { AnimatePresence, motion } from 'framer-motion'

export function Toast({ message, show }: { message: string; show: boolean }) {
  return (
    <AnimatePresence>
      {show && (
        <div
          className="fixed z-[1200]"
          style={{
            top: 'calc(env(safe-area-inset-top) + 12px)',
            left: 'calc(50% - 40px)',
            transform: 'translateX(-50%)',
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
          >
            <div className="max-w-[92vw] rounded-2xl card px-4 py-2 text-sm text-white/90 text-center shadow-2xl border border-white/10">
              {message}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}