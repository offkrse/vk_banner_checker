import React from 'react'

export function PlaceholderTab({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="px-3 pt-3 pb-24">
      <div className="text-xl font-semibold mb-1">{title}</div>
      <div className="text-sm text-white/60 mb-6">{subtitle}</div>
      <div className="rounded-3xl card p-4 text-white/70">
        Здесь будет контент в следующей итерации.
      </div>
    </div>
  )
}
