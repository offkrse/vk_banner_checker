import React, { useMemo, useState } from 'react'
import type { FiltersFile, FilterTemplate, RootCondition, FilterRule, Op, PeriodType, Metric, ActionState } from '../lib/types'
import { motion, AnimatePresence } from 'framer-motion'
import { haptic } from '../lib/tg'
import { AccountPickerSheet } from './AccountPickerSheet'
import { InlineSelect } from "./InlineSelect";
import { InlineNumber } from './InlineNumber'
import { Sheet } from './Sheet'
import { IconCopy, IconTrash } from './Icon'
import { SwipeToDelete } from './SwipeToDelete'

function uid(prefix='id') { return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}` }
function cid() { return `c_${Math.random().toString(16).slice(2)}_${Date.now()}` }

const opLabel: Record<Op, string> = { LT:'<', LTE:'≤', GT:'>', GTE:'≥', EQ:'=' }
const periodLabel: Record<PeriodType, string> = { ALL_TIME:'всё время', TODAY:'сегодня', LAST_N_DAYS:'последние N дней', YESTERDAY:'вчера' }
const metricLabel: Record<Metric, string> = { RESULTS:'результатов', CLICKS:'кликов', CLICK_COST:'цена клика', RESULT_COST:'цена результата' }
const stateLabel: Record<ActionState, string> = { ENABLE:'Включить', DISABLE:'Выключить', NOOP:'Не трогать' }

type Prio = 1|2|3|4|5

const prioLabel: Record<Prio, string> = {
  1: '1 - Высший приоритет',
  2: '2 - Высокий приоритет',
  3: '3 - Средний приоритет',
  4: '4 - Низкий приоритет',
  5: '5 - Низший приоритет',
}

const prioClass: Record<Prio, string> = {
  1: 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/20',
  2: 'bg-lime-500/20 text-lime-200 border border-lime-400/20',
  3: 'bg-yellow-500/20 text-yellow-200 border border-yellow-400/20',
  4: 'bg-orange-500/20 text-orange-200 border border-orange-400/20',
  5: 'bg-red-500/20 text-red-200 border border-red-400/20',
}



export function FiltersTab({
  value, onChange, accounts
}: {
  value: FiltersFile
  onChange: (v: FiltersFile)=>void
  accounts: {id:string; name:string}[]
}) {
  const templates = value.templates || []
  const [prioFor, setPrioFor] = useState<string | null>(null)

  const addTemplate = () => {
    haptic('light')
    const tpl: FilterTemplate = {
      id: uid('tpl'),
      name: 'Новый фильтр',
      priority: 3,
      root: {
        type:'ROOT',
        accountsScope: { mode:'ALL' },
        conditions: [],
        child: {
          type:'FILTER',
          mode:'ALL',
          rules: [],
          action: { type:'SET_STATE', state:'NOOP' }
        }
      }
    }
    onChange({ ...value, templates: [tpl, ...templates] })
  }
  
  const removeTemplate = (id: string) => {
    haptic('medium')
    onChange({ ...value, templates: templates.filter(t => t.id !== id) })
  }

  const duplicateTemplate = (id: string) => {
    const t = templates.find(x => x.id === id)
    if (!t) return
    haptic('light')
    const copy = structuredClone(t) as FilterTemplate
    copy.id = uid('tpl')
    copy.name = t.name + ' (копия)'
    onChange({ ...value, templates: [copy, ...templates] })
  }

  const updateTemplate = (id: string, patch: Partial<FilterTemplate>) => {
    onChange({
      ...value,
      templates: templates.map(t => t.id === id ? ({ ...t, ...patch }) : t)
    })
  }
  

  return (
    <div className="px-3 pb-24 pt-3">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-xl font-semibold">Фильтры</div>
          <div className="text-sm text-white/60">Добавь фильтры</div>
        </div>
        <button onClick={addTemplate} className="rounded-2xl chip px-4 py-2">+ Добавить</button>
      </div>

      <div className="space-y-3">
        <AnimatePresence initial={false}>
          {templates.map(tpl => {
            const prio = (tpl.priority ?? 3) as Prio

            return (
              <motion.div
                key={tpl.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                className="rounded-3xl card p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <input
                    className="w-full bg-transparent text-lg font-semibold outline-none"
                    value={tpl.name}
                    onChange={e => updateTemplate(tpl.id, { name: e.target.value })}
                  />

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setPrioFor(tpl.id)}
                      className={"rounded-xl px-3 h-9 text-[13px] flex items-center justify-center " + prioClass[prio]}
                      title={prioLabel[prio]}
                    >
                      {prio}
                    </button>
            
                    <button
                      onClick={() => duplicateTemplate(tpl.id)}
                      className="rounded-xl chip p-2"
                      aria-label="Дублировать"
                      title="Дублировать"
                    >
                      <IconCopy className="h-5 w-5" />
                    </button>
            
                    <button
                      onClick={() => removeTemplate(tpl.id)}
                      className="rounded-xl chip p-2"
                      aria-label="Удалить"
                      title="Удалить"
                    >
                      <IconTrash className="h-5 w-5" />
                    </button>
                  </div>
                </div>
            
                <div className="mt-3">
                  <ReadableTemplate
                    tpl={tpl}
                    accounts={accounts}
                    onUpdateRoot={(root:any) => updateTemplate(tpl.id, { root })}
                  />
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>

      {templates.length === 0 && (
        <div className="mt-16 flex flex-col items-center justify-center text-center">
          <div className="text-4xl mb-3">🧩</div>
          <div className="text-lg font-semibold">Пока пусто</div>
          <div className="text-sm text-white/60">Нажми “Добавить”, чтобы создать шаблон</div>
        </div>
      )}
      <Sheet
        open={!!prioFor}
        onClose={() => setPrioFor(null)}
        title="Приоритет"
      >
        <div className="text-sm text-white/60 mb-3">
          1 - Высший приоритет, 5 - Низший приоритет
        </div>

        <div className="space-y-2">
          {([1,2,3,4,5] as Prio[]).map(p => (
            <button
              key={p}
              className={"w-full rounded-2xl px-3 py-3 text-left " + prioClass[p]}
              onClick={() => {
                if (!prioFor) return
                updateTemplate(prioFor, { priority: p })
                setPrioFor(null)
              }}
            >
              {prioLabel[p]}
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  )
}

function ReadableTemplate({
  tpl, accounts, onUpdateRoot
}: {
  tpl: any
  accounts: {id:string; name:string}[]
  onUpdateRoot: (root:any)=>void
}) {
  const root = tpl.root
  const [pickerOpen, setPickerOpen] = useState(false)
  const [addRootCondOpen, setAddRootCondOpen] = useState(false)

  const conditionsSafe = (root.conditions || []) as RootCondition[]

  const patchRootCond = (idx:number, next:any) => {
    const curr = root.conditions || []
    const nextConditions = [...curr]
    nextConditions[idx] = next
    onUpdateRoot({ ...root, conditions: nextConditions })
  }

  const removeRootCond = (idx:number) => {
    const nextConditions = conditionsSafe.filter((_, i) => i !== idx)
    onUpdateRoot({ ...root, conditions: nextConditions })
  }

  const spentConds = conditionsSafe
    .map((c:any, idx:number) => ({ c, idx }))
    .filter(x => x.c?.type === 'SPENT')

  const targetConds = conditionsSafe
    .map((c:any, idx:number) => ({ c, idx }))
    .filter(x => x.c?.type === 'TARGET_ACTION')

  const incomeConds = conditionsSafe
    .map((c:any, idx:number) => ({ c, idx }))
    .filter(x => x.c?.type === 'INCOME')

  // --- кабинеты
  const mode = root.accountsScope?.mode || 'ALL'
  const selected = root.accountsScope?.selected || []

  const setAll = () => onUpdateRoot({ ...root, accountsScope: { mode:'ALL' } })
  const setSelected = () => {
    const def = accounts[0] ? [accounts[0].id] : []
    onUpdateRoot({ ...root, accountsScope: { mode:'SELECTED', selected: selected.length ? selected : def } })
  }
  const toggleAcc = (id:string) => {
    const s = new Set(selected)
    s.has(id) ? s.delete(id) : s.add(id)
    onUpdateRoot({ ...root, accountsScope: { mode:'SELECTED', selected: Array.from(s) } })
  }

  // --- вложенный фильтр
  const child = root.child?.type === 'FILTER'
    ? root.child
    : { type:'FILTER', mode:'ANY', rules: [], action:{ type:'SET_STATE', state:'NOOP' } }

  const setChild = (next:any) => onUpdateRoot({ ...root, child: next })

  const addRule = () => {
    setChild({
      ...child,
      rules: [...(child.rules||[]), { type:'COST_RULE', spentRub: 100, metric:'RESULTS', op:'EQ', value: 0 }]
    })
  }

  const patchRule = (idx:number, rule:any) => {
    const rules = [...(child.rules||[])]
    rules[idx] = rule
    setChild({ ...child, rules })
  }

  const removeRule = (idx:number) => {
    const rules = (child.rules||[]).filter((_:any,i:number)=>i!==idx)
    setChild({ ...child, rules })
  }

  return (
    <div className="space-y-3">
      {/* Строка ROOT */}
      <div className="rounded-3xl bg-white/5 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-sm text-white">Глобальные условия</div>
          <button
            onClick={() => setAddRootCondOpen(true)}
            className="rounded-xl chip px-2.5 h-9 text-[13px] py-2"
          >
            + условие
          </button>
        </div>

        {/* Для кабинетов */}
        <div className="flex flex-wrap items-center gap-2 text-sm leading-7">
          <span className="text-white/70">Для кабинетов</span>

          <button
            onClick={() => setPickerOpen(true)}
            className="text-sm text-white underline underline-offset-4 decoration-white/30 hover:decoration-white/60"
          >
            {mode === "ALL" ? "все кабинеты" : `выбрано: ${selected.length}`}
          </button>

          {mode === "SELECTED" && (
            <div className="w-full mt-2 flex flex-wrap gap-2">
              {accounts.map((a) => (
                <button
                  key={a.id}
                  onClick={() => toggleAcc(a.id)}
                  className={
                    "rounded-xl px-2.5 h-9 text-[13px] py-2 " +
                    (selected.includes(a.id) ? "bg-white/15" : "chip")
                  }
                >
                  {a.name || a.id}
                </button>
              ))}
              {accounts.length === 0 && (
                <div className="text-white/50">Сначала добавь кабинет (+)</div>
              )}
            </div>
          )}
        </div>

        {/* Условия (вынести отдельно, чтобы было одинаковой ширины) */}
        <div className="mt-3">
          {spentConds.map(({ c: spent, idx: spentIdx }) => (
            <SwipeToDelete
              key={spent.cid || `spent_${spentIdx}`}
              onDelete={() => removeRootCond(spentIdx)}
            >
              <div className="w-full rounded-2xl bg-white/5 px-3 py-3">
                <div className="flex flex-wrap items-center gap-2 text-sm leading-7">
                  <span className="text-white/70">и потрачено за</span>
          
                  <InlineSelect
                    ariaLabel="Период"
                    value={spent.period?.type || "ALL_TIME"}
                    options={[
                      { value: "ALL_TIME", label: "всё время" },
                      { value: "TODAY", label: "сегодня" },
                      { value: "YESTERDAY", label: "вчера" },
                      { value: "LAST_N_DAYS", label: "последние" },
                    ]}
                    onChange={(t) => {
                      patchRootCond(spentIdx, {
                        ...spent,
                        period:
                          t === "LAST_N_DAYS"
                            ? { type: t, n: spent.period?.n ?? 1 }
                            : { type: t },
                      })
                    }}
                  />

                  {spent.period?.type === "LAST_N_DAYS" && (
                    <>
                      <InlineNumber
                        value={spent.period?.n ?? 1}
                        title="Последние N дней"
                        onChange={(n) =>
                          patchRootCond(spentIdx, {
                            ...spent,
                            period: { type: "LAST_N_DAYS", n: Math.max(1, n) },
                          })
                        }
                      />
                      <span className="text-white underline underline-offset-4 decoration-white/30">дней</span>
                    </>
                  )}

                  <InlineSelect
                    ariaLabel="Оператор"
                    value={spent.op || "LTE"}
                    options={[
                      { value: "LT", label: "<" },
                      { value: "LTE", label: "≤" },
                      { value: "EQ", label: "=" },
                      { value: "GTE", label: "≥" },
                      { value: "GT", label: ">" },
                    ]}
                    onChange={(op) => patchRootCond(spentIdx, { ...spent, op })}
                  />

                  <InlineNumber
                    value={Number(spent.valueRub ?? 0)}
                    title="Сколько потрачено (₽)?"
                    onChange={(v) => patchRootCond(spentIdx, { ...spent, valueRub: v })}
                  />

                  <span className="text-white/70">₽</span>
                </div>
              </div>
            </SwipeToDelete>
          ))}
        </div>
        {/* TARGET_ACTION */}
        {targetConds.map(({ c: target, idx: targetIdx }) => (
          <SwipeToDelete
            key={target.cid || `target_${targetIdx}`}
            onDelete={() => removeRootCond(targetIdx)}
          >
            <div className="w-full rounded-2xl bg-white/5 px-3 py-3">
              <div className="flex flex-wrap items-center gap-2 text-sm leading-7">
                <span className="text-white/70">и целевое действие</span>

                <InlineSelect
                  ariaLabel="Целевое действие"
                  value={target.target}
                  options={[
                    { value: "BOT_MESSAGE", label: "сообщение в бот" },
                    { value: "SITE", label: "сайт" },
                    { value: "LEADFORM", label: "лидформа" },
                    { value: "APP", label: "приложение" },
                  ]}
                  onChange={(v) => patchRootCond(targetIdx, { ...target, target: v as any })}
                />
              </div>
            </div>
          </SwipeToDelete>
        ))}

        {/* INCOME */}
        {incomeConds.map(({ c: income, idx: incomeIdx }) => (
          <SwipeToDelete
            key={income.cid || `income_${incomeIdx}`}
            onDelete={() => removeRootCond(incomeIdx)}
          >
            <div className="w-full rounded-2xl bg-white/5 px-3 py-3">
              <div className="flex flex-wrap items-center gap-2 text-sm leading-7">
                <span className="text-white/70">и доход за</span>

                <InlineSelect
                  ariaLabel="Период дохода"
                  value={income.period?.type || "ALL_TIME"}
                  options={[
                    { value: "ALL_TIME", label: "всё время" },
                    { value: "TODAY", label: "сегодня" },
                    { value: "YESTERDAY", label: "вчера" },
                    { value: "LAST_N_DAYS", label: "последние" },
                  ]}
                  onChange={(t) =>
                    patchRootCond(incomeIdx, {
                      ...income,
                      period: t === "LAST_N_DAYS"
                        ? { type: t, n: income.period?.n ?? 1 }
                        : { type: t },
                    })
                  }
                />

                {income.period?.type === "LAST_N_DAYS" && (
                  <>
                    <InlineNumber
                      value={income.period?.n ?? 1}
                      title="Последние N дней (доход)"
                      onChange={(n) =>
                        patchRootCond(incomeIdx, {
                          ...income,
                          period: { type: "LAST_N_DAYS", n: Math.max(1, n) },
                        })
                      }
                    />
                    <span className="text-white underline underline-offset-4 decoration-white/30">дней</span>
                  </>
                )}

                <InlineSelect
                  ariaLabel="Доход"
                  value={income.mode}
                  options={[
                    { value: "HAS", label: "есть" },
                    { value: "HAS_NOT", label: "нет" },
                    { value: "COMPARE", label: "сравнить" },
                    { value: "COMPARE_SPEND", label: "сравнить с расходом" },
                  ]}
                  onChange={(mode) =>
                    patchRootCond(incomeIdx, {
                      ...income,
                      mode: mode as any,
                      ...(mode === "COMPARE"
                        ? {
                            op: income.op || "GTE",
                            value: income.value ?? 0,
                            multiplier: undefined,
                            spendPeriod: undefined,
                          }
                        : mode === "COMPARE_SPEND"
                        ? {
                            op: income.op || "GTE",
                            multiplier: income.multiplier ?? 1,
                            spendPeriod: income.spendPeriod || { type: "ALL_TIME" },
                            value: undefined,
                          }
                        : {
                            op: undefined,
                            value: undefined,
                            multiplier: undefined,
                            spendPeriod: undefined,
                          }),
                    })
                  }
                />

                {/* твои куски COMPARE / COMPARE_SPEND оставь как есть,
                    они уже используют patchRootCond(incomeIdx, ...) */}
                {income.mode === "COMPARE" && (
                  <>
                    <InlineSelect
                      ariaLabel="Оператор дохода"
                      value={income.op || "GTE"}
                      options={[
                        { value: "LT", label: "<" },
                        { value: "LTE", label: "≤" },
                        { value: "EQ", label: "=" },
                        { value: "GTE", label: "≥" },
                        { value: "GT", label: ">" },
                      ]}
                      onChange={(op) => patchRootCond(incomeIdx, { ...income, op: op as any })}
                    />
                    <InlineNumber
                      value={income.value ?? 0}
                      title="Доход"
                      onChange={(v) => patchRootCond(incomeIdx, { ...income, value: v })}
                    />
                  </>
                )}

                {income.mode === "COMPARE_SPEND" && (
                  <>
                    <InlineSelect
                      ariaLabel="Знак"
                      value={income.op || "GTE"}
                      options={[
                        { value: "LT", label: "<" },
                        { value: "LTE", label: "≤" },
                        { value: "EQ", label: "=" },
                        { value: "GTE", label: "≥" },
                        { value: "GT", label: ">" },
                      ]}
                      onChange={(op) => patchRootCond(incomeIdx, { ...income, op: op as any })}
                    />

                    <span className="text-white/70">расхода на</span>
                    
                    <InlineNumber
                      value={income.multiplier ?? 1}
                      title="Больше на ..."
                      onChange={(v) => patchRootCond(incomeIdx, { ...income, multiplier: v })}
                    />

                    <span className="text-white/70">за</span>
                    
                    <InlineSelect
                      ariaLabel="Период расхода"
                      value={income.spendPeriod?.type || "ALL_TIME"}
                      options={[
                        { value: "ALL_TIME", label: "всё время" },
                        { value: "TODAY", label: "сегодня" },
                        { value: "YESTERDAY", label: "вчера" },
                        { value: "LAST_N_DAYS", label: "последние" },
                      ]}
                      onChange={(t) =>
                        patchRootCond(incomeIdx, {
                          ...income,
                          spendPeriod: t === "LAST_N_DAYS"
                            ? { type: t, n: income.spendPeriod?.n ?? 1 }
                            : { type: t },
                        })
                      }
                    />

                    {income.spendPeriod?.type === "LAST_N_DAYS" && (
                      <>
                        <InlineNumber
                          value={income.spendPeriod?.n ?? 1}
                          title="Последние N дней (расход)"
                          onChange={(n) =>
                            patchRootCond(incomeIdx, {
                              ...income,
                              spendPeriod: { type: "LAST_N_DAYS", n: Math.max(1, n) },
                            })
                          }
                        />
                        <span className="text-white underline underline-offset-4 decoration-white/30">дней</span>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </SwipeToDelete>
        ))}
        {/* Вложенность */}
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">Фильтр</div>
            <button onClick={addRule} className="rounded-xl chip px-2.5 h-9 text-[13px] py-2 text-sm">+ условие</button>
          </div>
          {/* режим совпадения условий */}
            <div className="mt-2 flex items-center gap-2 text-sm">
              <span className="text-white/70">
                {child.mode === 'ANY' ? 'Совпадает' : 'Совпадают'}
              </span>
                
              <InlineSelect
                ariaLabel="Режим условий"
                value={child.mode || 'ALL'}
                options={[
                  { value: 'ANY', label: 'одно' },
                  { value: 'ALL', label: 'все' },
                ]}
                onChange={(mode) => setChild({ ...child, mode: mode as any })}
              />
          
              <span className="text-white/70">услови{child.mode === 'ALL' ? 'я' : 'е'}</span>
            </div>
          <div className="mt-3 space-y-2">
            {(child.rules || []).map((r:any, idx:number) => (
              <div key={idx} className="rounded-2xl bg-white/5 p-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2 text-sm flex-1 min-w-0">
                    <span className="text-white/70">Если потрачено</span>

                    <InlineNumber
                      value={Number(r.spentRub ?? 0)}
                      title="Потрачено (₽)"
                      onChange={(v) => patchRule(idx, { ...r, spentRub: v })}
                    />

                    <span className="text-white/70">₽</span>

                    <span className="inline-flex items-center gap-2 whitespace-nowrap">
                      <span className="text-white/70">и</span>
                      <InlineSelect
                        ariaLabel="Метрика"
                        value={r.metric}
                        options={[
                          { value: "RESULTS", label: "результатов" },
                          { value: "CLICKS", label: "кликов" },
                          { value: "RESULT_COST", label: "цена результата" },
                          { value: "CLICK_COST", label: "цена клика" },
                        ]}
                        onChange={(metric) => patchRule(idx, { ...r, metric })}
                      />
                    </span>

                    <InlineSelect
                      ariaLabel="Оператор"
                      value={r.op}
                      options={[
                        { value: "LT", label: "<" },
                        { value: "LTE", label: "≤" },
                        { value: "EQ", label: "=" },
                        { value: "GTE", label: "≥" },
                        { value: "GT", label: ">" },
                      ]}
                      onChange={(op) => patchRule(idx, { ...r, op })}
                    />

                    <InlineNumber
                      value={Number(r.value ?? 0)}
                      title="Значение"
                      onChange={(v) => patchRule(idx, { ...r, value: v })}
                    />
                  </div>
                    
                  <button
                    onClick={() => removeRule(idx)}
                    className="shrink-0 rounded-xl chip px-2.5 h-9 text-[13px] py-2 text-sm"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}

            {(child.rules || []).length === 0 && (
              <div className="text-sm text-white/50">Добавь условия фильтрации</div>
            )}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <span className="text-xs font-semibold text-white/80 bg-white/10 px-2 py-1 rounded-lg">Действие:</span>
                    
            <InlineSelect
              ariaLabel="Действие"
              value={child.action?.state || "NOOP"}
              options={[
                { value: "DISABLE", label: "выключить" },
                { value: "ENABLE", label: "включить" },
                { value: "NOOP", label: "не трогать" },
              ]}
              onChange={(state) => setChild({ ...child, action: { type:'SET_STATE', state: state as any } })}
            />
          </div>
        </div>
      </div>
      <Sheet open={addRootCondOpen} onClose={() => setAddRootCondOpen(false)} title="Добавить условие">
        <div className="space-y-2">
          <button
            className="w-full text-left rounded-2xl chip px-3 py-3"
            onClick={() => {
              setAddRootCondOpen(false)
              const next: RootCondition = { type:'SPENT', period:{type:'ALL_TIME'}, op:'LTE', valueRub: 2000, cid: cid() }
              onUpdateRoot({ ...root, conditions: [next, ...(root.conditions || [])] })
            }}
          >
            Потрачено
          </button>
          
          <button
            className="w-full text-left rounded-2xl chip px-3 py-3"
            onClick={() => {
              setAddRootCondOpen(false)
              const next: RootCondition = { type:'TARGET_ACTION', target:'BOT_MESSAGE', cid: cid() }
              onUpdateRoot({ ...root, conditions: [...(root.conditions || []), next] })
            }}
          >
            Целевое действие
          </button>
          
          <button
            className="w-full text-left rounded-2xl chip px-3 py-3"
            onClick={() => {
              setAddRootCondOpen(false)
              const next: RootCondition = { type:'INCOME', period:{type:'ALL_TIME'}, mode:'HAS', cid: cid() }
              onUpdateRoot({ ...root, conditions: [...(root.conditions || []), next] })
            }}
          >
            Доход
          </button>
        </div>
      </Sheet>
      <AccountPickerSheet
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        accounts={accounts}
        mode={mode}
        selected={selected}
        onChange={(next) => {
          if (next.mode === 'ALL') {
            onUpdateRoot({ ...root, accountsScope: { mode: 'ALL' } })
          } else {
            onUpdateRoot({ ...root, accountsScope: { mode: 'SELECTED', selected: next.selected } })
          }
        }}
      />
    </div>
  )
}

function OpChip({ value, onChange }: { value: Op; onChange:(v:Op)=>void }) {
  return (
    <InlineSelect
      ariaLabel="Оператор"
      value={value}
      options={[
        { value: "LT", label: "<" },
        { value: "LTE", label: "≤" },
        { value: "EQ", label: "=" },
        { value: "GTE", label: "≥" },
        { value: "GT", label: ">" },
      ]}
      onChange={(v) => onChange(v as Op)}
    />
  )
}

function NestedFilterEditor({ child, onChange }: any) {
  const rules = child.rules as FilterRule[]

  const addRule = () => {
    const next: FilterRule = { type:'COST_RULE', spentRub: 100, metric:'RESULTS', op:'EQ', value: 0 }
    onChange({ ...child, rules: [...rules, next] })
  }
  const remove = (idx:number) => onChange({ ...child, rules: rules.filter((_,i)=> i!==idx) })
  const patch = (idx:number, rule:FilterRule) => onChange({ ...child, rules: rules.map((r,i)=> i===idx ? rule : r) })

  return (
    <div className="mt-3 space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-white/70">Условия (FILTER)</div>
        <button onClick={addRule} className="rounded-xl chip px-3 py-2 text-sm">+ условие</button>
      </div>

      <div className="space-y-2">
        {rules.map((r, idx) => (
          <div key={idx} className="rounded-2xl bg-white/5 p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2 text-sm flex-1 min-w-0">
                <span className="text-white/70">Если потрачено</span>
                <input className="w-20 rounded-xl chip px-3 py-2 bg-transparent" inputMode="numeric" value={r.spentRub}
                  onChange={e => patch(idx, { ...r, spentRub: Number(e.target.value || 0) })} />
                <span className="text-white/70">₽</span>

                <span className="inline-flex items-center gap-2 whitespace-nowrap">
                  <span className="text-white/70">и</span>
                  <InlineSelect
                    ariaLabel="Метрика"
                    value={r.metric}
                    options={[
                      { value: "RESULTS", label: "результатов" },
                      { value: "CLICKS", label: "кликов" },
                      { value: "RESULT_COST", label: "цена результата" },
                      { value: "CLICK_COST", label: "цена клика" },
                    ]}
                    onChange={(metric) => patch(idx, { ...r, metric: metric as any })}
                  />
                </span>

                <OpChip value={r.op} onChange={(op)=> patch(idx, { ...r, op })} />
                <input className="w-20 rounded-xl chip px-3 py-2 bg-transparent" inputMode="numeric" value={r.value}
                  onChange={e => patch(idx, { ...r, value: Number(e.target.value || 0) })} />
              </div>
              <button onClick={()=> remove(idx)} className="shrink-0 rounded-xl chip px-2.5 h-9 text-[13px] py-2 text-sm">✕</button>
            </div>
          </div>
        ))}
        {rules.length === 0 && <div className="text-sm text-white/50">Добавь условия кнопкой “+ условие”</div>}
      </div>

      <div className="mt-3">
        <div className="text-sm text-white/70 mb-2">Действие при совпадении всех условий</div>
        <ActionPicker value={child.action.state} onChange={(s)=> onChange({ ...child, action: { type:'SET_STATE', state: s } })} />
      </div>
    </div>
  )
}

function ActionPicker({ value, onChange }: { value: ActionState; onChange:(v:ActionState)=>void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {(['NOOP','ENABLE','DISABLE'] as ActionState[]).map(s => (
        <button key={s} onClick={()=> onChange(s)}
          className={'rounded-xl px-3 py-2 text-sm ' + (value===s ? 'bg-white/15' : 'chip')}>
          {stateLabel[s]}
        </button>
      ))}
    </div>
  )
}
