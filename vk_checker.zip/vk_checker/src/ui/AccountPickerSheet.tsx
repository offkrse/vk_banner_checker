import React from "react";
import { Sheet } from "./Sheet";

export function AccountPickerSheet({
  open,
  onClose,
  accounts,
  mode,
  selected,
  onChange,
}: {
  open: boolean;
  onClose: () => void;
  accounts: { id: string; name: string }[];
  mode: "ALL" | "SELECTED";
  selected: string[];
  onChange: (next: { mode: "ALL" | "SELECTED"; selected: string[] }) => void;
}) {
  const toggle = (id: string) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    onChange({ mode: "SELECTED", selected: Array.from(s) });
  };

  const title = "Кабинеты";

  return (
    <Sheet open={open} onClose={onClose} title={title}>
      <div className="space-y-3">
        <div className="flex gap-2">
          <button
            onClick={() => onChange({ mode: "ALL", selected: [] })}
            className={
              "flex-1 rounded-2xl px-3 py-3 text-sm " +
              (mode === "ALL" ? "bg-white/15" : "chip")
            }
          >
            Все
          </button>
          <button
            onClick={() =>
              onChange({
                mode: "SELECTED",
                selected: selected.length ? selected : [],
              })
            }
            className={
              "flex-1 rounded-2xl px-3 py-3 text-sm " +
              (mode === "SELECTED" ? "bg-white/15" : "chip")
            }
          >
            Выбранные
          </button>
        </div>

        <div className="rounded-3xl bg-white/5 p-3">
          {accounts.length === 0 ? (
            <div className="text-sm text-white/60">
              Кабинетов нет. Добавь кабинет кнопкой “+” вверху.
            </div>
          ) : (
            <div className="space-y-2">
              {accounts.map((a) => {
                const active = mode === "ALL" ? true : selected.includes(a.id);

                return (
                  <button
                    key={a.id}
                    onClick={() => toggle(a.id)}
                    className={
                      "w-full h-12 rounded-2xl px-3 flex items-center gap-3 text-left " +
                      "bg-white/5 active:bg-white/10 " +
                      (active ? "ring-1 ring-white/15" : "ring-1 ring-transparent")
                    }
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{a.name || a.id}</div>
                      <div className="text-xs text-white/50 truncate">id: {a.id}</div>
                    </div>
                  
                    {/* место под галку всегда занято */}
                    <div
                      className={
                        "w-5 h-5 rounded-full border border-white/20 flex items-center justify-center " +
                        (active ? "bg-white/15" : "bg-transparent")
                      }
                    >
                      <span className={"text-xs " + (active ? "opacity-100" : "opacity-0")}>✓</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
        {mode === "SELECTED" && (
          <div className="text-xs text-white/50">
            Выбрано: {selected.length}
          </div>
        )}
        {mode === "SELECTED" && (
          <div className="text-xs text-white/50">
            Подсказка: если не выбрано ничего - фильтр не применится ни к одному
            кабинету.
          </div>
        )}
      </div>
    </Sheet>
  );
}