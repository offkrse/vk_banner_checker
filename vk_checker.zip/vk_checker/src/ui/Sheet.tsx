import React, { PropsWithChildren, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { createPortal } from 'react-dom'

export function Sheet({
  open, onClose, title, children
}: PropsWithChildren<{ open:boolean; onClose:()=>void; title?:string }>) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const content = (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[1000] bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="fixed left-0 right-0 bottom-0 z-[1001]"
            initial={{ y: 420 }}
            animate={{ y: 0 }}
            exit={{ y: 420 }}
            transition={{ type: 'spring', stiffness: 280, damping: 30 }}
            style={{ willChange: 'transform' }}
          >
            <div
              className="mx-auto w-full max-w-md rounded-t-3xl card safe-bottom shadow-2xl overflow-hidden"
              style={{ maxHeight: '82vh' }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="pt-3">
                <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-white/15" />
              </div>

              <div className="px-4 pb-3 border-b border-white/10">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-base font-semibold truncate">{title}</div>
                  <button
                    onClick={onClose}
                    className="shrink-0 rounded-xl chip w-9 h-9 flex items-center justify-center text-sm"
                    aria-label="Закрыть"
                    title="Закрыть"
                  >
                    ✕
                  </button>
                </div>
              </div>

              <div
                className="px-4 py-3 overflow-y-auto"
                style={{ maxHeight: 'calc(82vh - 76px)' }}
              >
                {children}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )

  return createPortal(content, document.body)
}