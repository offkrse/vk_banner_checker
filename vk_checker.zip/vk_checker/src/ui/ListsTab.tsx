import React, { useEffect, useMemo, useState } from "react"
import { motion } from "framer-motion"
import type { ListFile } from "../lib/types"
import { api } from "../lib/api"

type ListsSubTab = "white" | "black"

const subTabs: { key: ListsSubTab; label: string }[] = [
  { key: "white", label: "Белый список" },
  { key: "black", label: "Чёрный список" },
]

function uniqCleanLines(text: string): string[] {
  const arr = text
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean)

  // уникальные, сохраняем порядок
  const seen = new Set<string>()
  const out: string[] = []
  for (const x of arr) {
    if (seen.has(x)) continue
    seen.add(x)
    out.push(x)
  }
  return out
}

function toText(lines: string[]) {
  return (lines || []).join("\n")
}

export function ListsTab({ showToast }: { showToast: (m: string) => void }) {
  const [subTab, setSubTab] = useState<ListsSubTab>("white")
  const [loading, setLoading] = useState(false)

  const [white, setWhite] = useState<ListFile>({ campaign_ids: [], banner_ids: [] })
  const [black, setBlack] = useState<ListFile>({ campaign_ids: [], banner_ids: [] })

  // локальный текст (textarea)
  const [whiteCampaigns, setWhiteCampaigns] = useState("")
  const [whiteBanners, setWhiteBanners] = useState("")
  const [blackCampaigns, setBlackCampaigns] = useState("")
  const [blackBanners, setBlackBanners] = useState("")

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        setLoading(true)
        const [w, b] = await Promise.all([api.getList("white"), api.getList("black")])
        if (!alive) return
        setWhite(w)
        setBlack(b)
        setWhiteCampaigns(toText(w.campaign_ids))
        setWhiteBanners(toText(w.banner_ids))
        setBlackCampaigns(toText(b.campaign_ids))
        setBlackBanners(toText(b.banner_ids))
      } catch (e: any) {
        showToast(e?.message || "Ошибка загрузки списков")
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => { alive = false }
  }, [])

  const hint = useMemo(() => {
    return subTab === "white"
      ? {
          top: "Действия будут происходить только с этими кампаниями/баннерами",
          c: "Введите id компании в столбик, без запятых",
          b: "Введите id баннера в столбик, без запятых",
        }
      : {
          top: "Введенные кампания/баннера не будут затрагиваться",
          c: "Введите id компании в столбик, без запятых",
          b: "Введите id баннера в столбик, без запятых",
        }
  }, [subTab])

  const save = async () => {
    try {
      const kind = subTab
      const payload: ListFile =
        kind === "white"
          ? {
              campaign_ids: uniqCleanLines(whiteCampaigns),
              banner_ids: uniqCleanLines(whiteBanners),
            }
          : {
              campaign_ids: uniqCleanLines(blackCampaigns),
              banner_ids: uniqCleanLines(blackBanners),
            }

      await api.saveList(kind, payload)

      if (kind === "white") setWhite(payload)
      else setBlack(payload)

      showToast("Список сохранён")
    } catch (e: any) {
      showToast(e?.message || "Ошибка сохранения списка")
    }
  }

  return (
    <div className="px-3 pb-24 pt-3">
      {/* внутренний бар (как табы), на всю ширину */}
      <div className="sticky top-[55px] z-20 -mx-3 -mt-3">
        <div className="glass border border-white/10">
          <div className="flex overflow-x-auto no-scrollbar">
            {subTabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setSubTab(t.key)}
                className="relative flex-1 px-3 py-3 text-sm font-medium text-white/80 whitespace-nowrap"
              >
                <span className={subTab === t.key ? "text-white" : ""}>{t.label}</span>

                {subTab === t.key && (
                  <motion.div
                    layoutId="lists-subtab-underline"
                    className="absolute left-3 right-3 bottom-1 h-1 rounded-full bg-white/70"
                    transition={{ type: "spring", stiffness: 500, damping: 36 }}
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-3 space-y-3">
        {loading && (
          <div className="rounded-2xl bg-white/5 p-3 text-sm text-white/60">Загрузка…</div>
        )}

        <div className="rounded-2xl bg-white/5 p-3 text-sm text-white/70">
          {hint.top}
        </div>

        <div className="rounded-3xl bg-white/5 p-3 space-y-2">
          <div className="text-sm text-white/60">{hint.c}</div>
          <textarea
            className="w-full min-h-[140px] rounded-2xl chip bg-transparent px-4 py-3 outline-none text-sm whitespace-pre-wrap"
            value={subTab === "white" ? whiteCampaigns : blackCampaigns}
            onChange={(e) => (subTab === "white" ? setWhiteCampaigns(e.target.value) : setBlackCampaigns(e.target.value))}
            placeholder="111&#10;222&#10;333"
          />

          <div className="text-sm text-white/60 mt-3">{hint.b}</div>
          <textarea
            className="w-full min-h-[140px] rounded-2xl chip bg-transparent px-4 py-3 outline-none text-sm whitespace-pre-wrap"
            value={subTab === "white" ? whiteBanners : blackBanners}
            onChange={(e) => (subTab === "white" ? setWhiteBanners(e.target.value) : setBlackBanners(e.target.value))}
            placeholder="111&#10;222&#10;333"
          />

          <button onClick={save} className="w-full rounded-2xl bg-white/15 py-3 text-sm font-medium mt-2">
            Сохранить
          </button>
        </div>
      </div>
    </div>
  )
}
