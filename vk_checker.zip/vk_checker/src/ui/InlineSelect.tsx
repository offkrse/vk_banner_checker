import React, { useMemo, useState } from "react";
import { Sheet } from "./Sheet";

type Option = { value: string; label: string };

export function InlineSelect({
  value,
  options,
  onChange,
  ariaLabel,
}: {
  value: string;
  options: Option[];
  onChange: (v: string) => void;
  ariaLabel?: string;
}) {
  const [open, setOpen] = useState(false);

  const current = useMemo(
    () => options.find((o) => o.value === value)?.label ?? value,
    [value, options]
  );

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center text-sm text-white underline underline-offset-4 decoration-white/30 hover:decoration-white/60"
      >
        {current}
      </button>

      <Sheet open={open} onClose={() => setOpen(false)} title={ariaLabel || "Выбор"}>
        <div className="space-y-2">
          {options.map((o) => {
            const active = o.value === value;
            return (
              <button
                key={o.value}
                onClick={() => {
                  onChange(o.value);
                  setOpen(false);
                }}
                className={
                  "w-full text-left rounded-2xl px-3 py-3 " +
                  (active ? "bg-white/15" : "chip")
                }
              >
                {o.label}
              </button>
            );
          })}
        </div>
      </Sheet>
    </>
  );
}