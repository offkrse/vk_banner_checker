import React from 'react'
import { motion } from 'framer-motion'

export type TabKey = 'filters'|'history'|'settings'|'lists'

const tabs: { key: TabKey; label: string }[] = [
  { key: 'filters', label: 'Фильтры' },
  { key: 'history', label: 'История' },
  { key: 'settings', label: 'Настройки' },
  { key: 'lists', label: 'Списки' },
]

export function TopTabs({ value, onChange }: { value: TabKey; onChange: (v: TabKey)=>void }) {
  return (
    <div className="z-20">
      <div className="glass border border-white/10">
        <div className="flex">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => onChange(t.key)}
              className="relative flex-1 px-3 py-3 text-sm font-medium text-white/80 whitespace-nowrap"
            >
              <span className={value === t.key ? 'text-white' : ''}>{t.label}</span>

              {value === t.key && (
                <motion.div
                  layoutId="tab-underline"
                  className="absolute left-3 right-3 bottom-1 h-1 rounded-full bg-white/70"
                  transition={{ type:'spring', stiffness: 500, damping: 36 }}
                />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
