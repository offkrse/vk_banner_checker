import React, { useEffect, useState } from "react";
import { Modal } from "./Modal";

export function InlineNumber({
  value,
  onChange,
  title = "Введите число",
  min,
}: {
  value: number;
  onChange: (v: number) => void;
  title?: string;
  min?: number;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(String(value ?? 0));

  useEffect(() => {
    if (open) setDraft(String(value ?? 0));
  }, [open, value]);

  const apply = () => {
    const n = Number(draft);
    const next = Number.isFinite(n) ? n : 0;
    onChange(min != null ? Math.max(min, next) : next);
    setOpen(false);
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="text-sm text-white underline underline-offset-4 decoration-white/30 hover:decoration-white/60"
      >
        {value}
      </button>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={title}
        footer={
          <div className="flex gap-2">
            <button onClick={() => setOpen(false)} className="flex-1 rounded-2xl chip py-3">Отмена</button>
            <button onClick={apply} className="flex-1 rounded-2xl bg-white/15 py-3">Ок</button>
          </div>
        }
      >
        <input
          className="w-full rounded-2xl chip bg-transparent px-4 py-3 outline-none"
          inputMode="numeric"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
      </Modal>
    </>
  );
}
