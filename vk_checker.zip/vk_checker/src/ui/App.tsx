import React, { useEffect, useMemo, useState } from 'react'
import { TopTabs, TabKey } from './TopTabs'
import { IconPerson, IconPlus, IconMoney } from './Icon'
import { Sheet } from './Sheet'
import { Modal } from './Modal'
import { Toast } from './Toast'
import { api } from '../lib/api'
import { getInitData, haptic } from '../lib/tg'
import type { AccountItem, FiltersFile, SettingsFile } from '../lib/types'
import { FiltersTab } from './FiltersTab'
import { SettingsTab } from './SettingsTab'
import { PlaceholderTab } from './PlaceholderTab'
import { HistoryTab } from './HistoryTab'
import { ListsTab } from './ListsTab'
import { AdminPanel } from "./AdminPanel";

type BootState = {
  tg_id: string
  tg_username: string
  accounts: AccountItem[]
  filters: FiltersFile
  settings: SettingsFile
  income_path: string
  is_admin?: boolean
}

function tplId() {
  return `tpl_${Math.random().toString(16).slice(2)}_${Date.now()}`
}

function makeBaseTemplates() {
  return [
    {
      id: tplId(),
      name: "Доходные",
      priority: 1,
      root: {
        type: "ROOT",
        accountsScope: { mode: "ALL", selected: null },
        conditions: [
          { type: "SPENT", period: { type: "LAST_N_DAYS", n: 2 }, op: "GTE", valueRub: 100.0 },
          { type: "INCOME", period: { type: "LAST_N_DAYS", n: 2 }, mode: "HAS", op: null, value: null, multiplier: null, spendPeriod: null },
        ],
        child: {
          type: "FILTER",
          mode: "ANY",
          rules: [],
          action: { type: "SET_STATE", state: "ENABLE" },
        },
      },
    },
    {
      id: tplId(),
      name: "Базовый фильтр",
      priority: 3,
      root: {
        type: "ROOT",
        accountsScope: { mode: "ALL", selected: null },
        conditions: [
          { type: "SPENT", period: { type: "ALL_TIME", n: null }, op: "LTE", valueRub: 2000.0 },
          { type: "INCOME", period: { type: "LAST_N_DAYS", n: 4 }, mode: "HAS_NOT", op: null, value: null, multiplier: null, spendPeriod: null },
        ],
        child: {
          type: "FILTER",
          mode: "ANY",
          rules: [
            { type: "COST_RULE", spentRub: 240.0, metric: "RESULTS", op: "EQ", value: 0.0 },
            { type: "COST_RULE", spentRub: 110.0, metric: "CLICKS", op: "EQ", value: 0.0 },
            { type: "COST_RULE", spentRub: 300.0, metric: "RESULT_COST", op: "GTE", value: 300.0 },
          ],
          action: { type: "SET_STATE", state: "DISABLE" },
        },
      },
    },
  ] as any
}

export function App() {
  const [tab, setTab] = useState<TabKey>('filters')
  const [boot, setBoot] = useState<BootState | null>(null)
  const [loading, setLoading] = useState(true)

  // Accounts UI
  const [adminOpen, setAdminOpen] = useState(false);

  const [accountsOpen, setAccountsOpen] = useState(false)
  const [tokenModalOpen, setTokenModalOpen] = useState(false)
  const [confirmOpen, setConfirmOpen] = useState(false)

  const [tokenInput, setTokenInput] = useState('')
  const [validated, setValidated] = useState<{id:string; client_name:string; email?:string} | null>(null)

  //sub1 picker
  const [incomeModalOpen, setIncomeModalOpen] = useState(false)
  const [sub1Required, setSub1Required] = useState(false)

  const pickSub1 = async (sub1: 'krolik'|'insta'|'zarplatkinrf'|'nalickinrf'|'karakoz_karas'|'utkavalutkarf'|'vydavayka'|'1russ') => {
    try {
      const res = await api.setIncomePath(sub1)
      setBoot(prev => prev ? ({ ...prev, income_path: res.income_path }) : prev)
      setIncomeModalOpen(false)
      showToast('Sub1 сохранён')
    } catch (e:any) {
      showToast(e?.message || 'Ошибка сохранения Sub1')
    }
  }

  //восстановления базового фильтра
  const restoreBaseFilters = async () => {
    if (!boot) return

    const base = makeBaseTemplates()
    const existing = boot.filters?.templates || []

    // чтобы не плодить дубли по 100 раз
    const hasIncome = existing.some(t => t?.name === "Доходные")
    const hasBase = existing.some(t => t?.name === "Базовый фильтр")

    const toAdd = [
      ...(hasIncome ? [] : [base[0]]),
      ...(hasBase ? [] : [base[1]]),
    ]

    if (toAdd.length === 0) {
      showToast("Базовые фильтры уже есть")
      return
    }

    const nextFilters = {
      ...boot.filters,
      templates: [...toAdd, ...existing],
    }

    setBoot({ ...boot, filters: nextFilters })

    try {
      await api.saveFilters(nextFilters)
      showToast("Базовые фильтры восстановлены")
    } catch (e: any) {
      showToast(e?.message || "Ошибка сохранения фильтров")
    }
  }

  // Save feedback
  const [toast, setToast] = useState<{show:boolean; msg:string}>({show:false, msg:''})
  const showToast = (msg: string) => {
    setToast({show:true, msg})
    setTimeout(()=> setToast({show:false, msg:''}), 1800)
  }

  useEffect(() => {
    (async () => {
      try {
        const existingJwt = localStorage.getItem('vk_checker_jwt')
        let res: any = null

        if (existingJwt) {
          try {
            // пробуем работать по текущему JWT (в том числе impersonate)
            res = await api.state()
          } catch (e) {
            // JWT битый / истёк — чистим
            localStorage.removeItem('vk_checker_jwt')
            res = null
          }
        }

        if (!res) {
          const initData = getInitData()
          if (!initData) {
            showToast('Открой как Telegram Mini App')
            setLoading(false)
            return
          }

          // fallback — обычный логин через Telegram
          res = await api.bootstrap(initData)
        }

        // res может быть либо от state(), либо от bootstrap()
        const user = res.user ?? res

        setBoot({
          tg_id: String(user.tg_id || ''),
          tg_username: String(user.tg_username || ''),
          accounts: user.accounts || [],
          filters: user.filters || { version: 1, templates: [] },
          settings: user.settings || { ignore_manual_enabled_ads: true },
          income_path: user.income_path || '',
          is_admin: !!user.is_admin,
        })

        if (!user.income_path) {
          setSub1Required(true)
          setIncomeModalOpen(true)
        } else {
          setSub1Required(false)
        }
      } catch (e: any) {
        showToast(e?.message || 'Ошибка загрузки')
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const accountsLite = useMemo(() => (boot?.accounts || []).map(a => ({ id: a.id, name: a.name })), [boot])

  const saveFilters = async (filters: FiltersFile) => {
    if (!boot) return
    setBoot({ ...boot, filters })
    try {
      await api.saveFilters(filters)
      showToast('Фильтры сохранены')
    } catch (e: any) {
      showToast(e?.message || 'Ошибка сохранения')
    }
  }

  const saveSettings = async (settings: SettingsFile) => {
    if (!boot) return
    setBoot({ ...boot, settings })
    try {
      await api.saveSettings(settings)
      showToast('Настройки сохранены')
    } catch (e: any) {
      showToast(e?.message || 'Ошибка сохранения')
    }
  }

  const openAddToken = () => {
    haptic('light')
    setTokenInput('')
    setValidated(null)
    setTokenModalOpen(true)
  }

  const validateToken = async () => {
    try {
      if (!tokenInput.trim()) return
      const v = await api.validateToken(tokenInput.trim())
      setValidated(v)
      setTokenModalOpen(false)
      setConfirmOpen(true)
    } catch (e: any) {
      showToast(e?.message || 'Токен невалидный')
    }
  }

  const confirmToken = async () => {
    if (!validated) return
    try {
      const res = await api.confirmToken(tokenInput.trim(), validated.id, validated.client_name)
      setConfirmOpen(false)
      showToast('Кабинет добавлен')
      // refresh accounts
      setBoot(prev => prev ? ({ ...prev, accounts: res.accounts }) : prev)
    } catch (e: any) {
      showToast(e?.message || 'Ошибка добавления')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="rounded-3xl card px-5 py-4">
          <div className="text-base font-semibold">Загрузка…</div>
          <div className="text-sm text-white/60 mt-1">Подключаем данные</div>
        </div>
      </div>
    )
  }

  const isImpersonating = Boolean(localStorage.getItem('vk_checker_admin_jwt'))

  return (
    <div className="min-h-screen">
      <Toast show={toast.show} message={toast.msg} />

      <TopBar
        tab={tab}
        onTab={setTab}
        onAccounts={() => setAccountsOpen(true)}
        onAddToken={openAddToken}
        onIncome={() => {
          setSub1Required(false)
          setIncomeModalOpen(true)
        }}
        onAdmin={() => setAdminOpen(true)}
        onBackToAdmin={() => {
          const adminJwt = localStorage.getItem('vk_checker_admin_jwt')
          if (!adminJwt) return
          localStorage.setItem('vk_checker_jwt', adminJwt)
          localStorage.removeItem('vk_checker_admin_jwt')
          window.location.reload()
        }}
        isAdmin={!!boot?.is_admin}
        isImpersonating={isImpersonating}
      />

      {boot && tab === 'filters' && (
        <FiltersTab value={boot.filters} onChange={saveFilters} accounts={accountsLite} />
      )}
      {boot && tab === 'settings' && (
        <SettingsTab
          value={boot.settings}
          onChange={saveSettings}
          onRestoreBaseFilters={restoreBaseFilters}
        />
      )}
      {boot && tab === 'history' && (
        <HistoryTab
          accounts={boot.accounts}
          settings={boot.settings}
          onSaveSettings={saveSettings}
          showToast={showToast}
        />
      )}
      {tab === 'lists' && (
        <ListsTab showToast={showToast} />
      )}

      <Sheet open={accountsOpen} onClose={() => setAccountsOpen(false)} title="Кабинеты">
        <div className="space-y-2">
          {(boot?.accounts || []).length === 0 && (
            <div className="text-sm text-white/60">Кабинетов нет. Нажми “+” вверху справа.</div>
          )}
          {(boot?.accounts || []).map(a => (
            <div key={a.id} className="rounded-2xl bg-white/5 p-3">
              <div className="font-medium">{a.name}</div>
              <div className="text-sm text-white/60">id: {a.id}</div>
            </div>
          ))}
        </div>
      </Sheet>

      <Modal
        open={tokenModalOpen}
        onClose={() => setTokenModalOpen(false)}
        title="Добавить токен"
        footer={
          <div className="flex gap-2">
            <button onClick={() => setTokenModalOpen(false)} className="flex-1 rounded-2xl chip py-3">Отмена</button>
            <button onClick={validateToken} className="flex-1 rounded-2xl bg-white/15 py-3">Проверить</button>
          </div>
        }
      >
        <div className="text-sm text-white/60">Введи токен кабинета</div>
        <input
          className="w-full rounded-2xl chip bg-transparent px-4 py-3 outline-none"
          placeholder="VK token…"
          value={tokenInput}
          onChange={e => setTokenInput(e.target.value)}
        />
      </Modal>

      <Modal
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title="Ваш кабинет?"
        footer={
          <div className="flex gap-2">
            <button onClick={() => setConfirmOpen(false)} className="flex-1 rounded-2xl chip py-3">Нет</button>
            <button onClick={confirmToken} className="flex-1 rounded-2xl bg-white/15 py-3">Да</button>
          </div>
        }
      >
        <div className="rounded-2xl bg-white/5 p-3">
          <div className="text-lg font-semibold">{validated?.client_name || '-'}</div>
          <div className="text-sm text-white/60">id: {validated?.id || '-'}</div>
          {validated?.email && <div className="text-sm text-white/60">email: {validated.email}</div>}
        </div>
      </Modal>
      <Sheet
        open={incomeModalOpen}
        onClose={() => {
          if (sub1Required) return
          setIncomeModalOpen(false)
        }}
        title="Выберите Sub1"
      >
        <div className="space-y-2">
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('krolik')}>
            krolik
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('insta')}>
            insta
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('zarplatkinrf')}>
            zarplatkinrf
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('nalickinrf')}>
            nalickinrf
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('karakoz_karas')}>
            karakoz / karas
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('utkavalutkarf')}>
            utkavalutkarf
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('vydavayka')}>
            vydavayka
          </button>
          <button className="w-full text-left rounded-2xl chip px-3 py-3" onClick={() => pickSub1('1russ')}>
            1russ / vadimtop
          </button>
      
          {sub1Required && (
            <div className="text-xs text-white/50 mt-2">
              Нужно выбрать Sub1, чтобы корректно считать доход.
            </div>
          )}
        </div>
      </Sheet>
      <AdminPanel
        open={adminOpen}
        onClose={() => setAdminOpen(false)}
      />
    </div>
  )
}

function TopBar({
  tab,
  onTab,
  onAccounts,
  onAddToken,
  onIncome,
  onAdmin,
  onBackToAdmin,
  isAdmin,
  isImpersonating,
}: {
  tab: TabKey
  onTab: (t: TabKey)=>void
  onAccounts: ()=>void
  onAddToken: ()=>void
  onIncome: ()=>void
  onAdmin: ()=>void
  onBackToAdmin: ()=>void
  isAdmin?: boolean
  isImpersonating?: boolean
}) {
  return (
    <>
      <div className="sticky top-0 z-30">
        <div className="glass border border-white/10 px-3 py-2 flex items-center justify-between">
          <div className="text-sm text-white/70">VK Checker</div>

          <div className="flex items-center gap-2">

            {isImpersonating && (
              <button
                onClick={onBackToAdmin}
                className="rounded-2xl chip p-2"
                aria-label="Вернуться в админа"
                title="Вернуться в админа"
              >
                ↩
              </button>
            )}

            {isAdmin && (
              <button
                onClick={onAdmin}
                className="rounded-2xl chip p-2"
                aria-label="Admin panel"
              >
                🛠
              </button>
            )}

            <button onClick={onIncome} className="rounded-2xl chip p-2" aria-label="Sub1">
              <IconMoney className="h-5 w-5" />
            </button>

            <button onClick={onAccounts} className="rounded-2xl chip p-2">
              <IconPerson className="h-5 w-5" />
            </button>

            <button onClick={onAddToken} className="rounded-2xl chip p-2">
              <IconPlus className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="sticky z-20">
        <TopTabs value={tab} onChange={onTab} />
      </div>
    </>
  )
}
