import React, { PropsWithChildren, useState } from "react";
import { motion, useMotionValue, useTransform } from "framer-motion";

export function SwipeToDelete({
  onDelete,
  disabled,
  children,
}: PropsWithChildren<{
  onDelete: () => void;
  disabled?: boolean;
}>) {
  const [gone, setGone] = useState(false);

  // двигаем только контент
  const x = useMotionValue(0);

  // фон "Удалить" НЕ виден в состоянии покоя
  // начинает проявляться только когда свайпнули влево
  const bgOpacity = useTransform(x, [0, -30, -140], [0, 0.35, 1]);

  return (
    <div className="relative w-full overflow-hidden rounded-2xl mt-[3px]">
      {/* фон удаления (сзади) */}
      <motion.div
        className="absolute inset-0 z-0 bg-red-500/25 flex items-center justify-end pr-4 pointer-events-none"
        style={{ opacity: bgOpacity }}
      >
        <div className="text-red-100 text-sm">Удалить</div>
      </motion.div>

      {/* контент (сверху) */}
      <motion.div
        className="relative z-10 w-full"
        drag={disabled ? false : "x"}
        dragDirectionLock
        dragConstraints={{ left: -140, right: 0 }}
        dragElastic={0.12}
        style={{ x, willChange: "transform" }}
        onDragEnd={(_, info) => {
          if (disabled) return;
          if (info.offset.x < -90) {
            setGone(true);
            onDelete();
          }
        }}
        animate={gone ? { x: -320, opacity: 0 } : { opacity: 1 }}
        transition={{ type: "spring", stiffness: 520, damping: 42 }}
      >
        {children}
      </motion.div>
    </div>
  );
}