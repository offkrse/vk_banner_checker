import React, { useEffect, useMemo, useState } from "react"
import type { AccountItem, HistoryBanner, SettingsFile, HistorySettings } from "../lib/types"
import { Sheet } from "./Sheet"
import { Modal } from "./Modal"
import { IconDots, IconGear } from "./Icon"
import { api } from "../lib/api"

function pad2(n: number) { return String(n).padStart(2, "0") }

function roundToNearestHalfHour(dt: Date) {
  const m = dt.getMinutes()
  const nearest = Math.round(m / 30) * 30
  dt.setMinutes(nearest, 0, 0)
  return dt
}

function bucketKey(daytime: string) {
  // daytime: "YYYY-MM-DD HH:mm:ss"
  const dt = new Date(daytime.replace(" ", "T"))
  const rounded = roundToNearestHalfHour(new Date(dt))
  return `${rounded.getFullYear()}-${pad2(rounded.getMonth()+1)}-${pad2(rounded.getDate())} ${pad2(rounded.getHours())}:${pad2(rounded.getMinutes())}`
}

function defaultHistorySettings(s?: HistorySettings): HistorySettings {
  return {
    performance_mode: s?.performance_mode ?? false,
    show_disabled: s?.show_disabled ?? true,
    show_enabled: s?.show_enabled ?? true,
  }
}

function formatDateRU(iso: string) {
  // iso: "2025-12-20"
  const [y, m, d] = iso.split("-")
  return `${d}.${m}.${y}`
}

function pickTimeFromBucketKey(key: string) {
  // "YYYY-MM-DD HH:mm" -> "HH:mm"
  const parts = key.split(" ")
  return parts[1] || key
}

function BannerCard({
  b,
  performanceMode,
  showToast,
}: {
  b: HistoryBanner
  performanceMode: boolean
  showToast: (msg: string) => void
}) {
  const isOff = String(b.status).toLowerCase() === "off"
  const [reasonOpen, setReasonOpen] = useState(false)
  const [statsOpen, setStatsOpen] = useState(false)

  const shortReason = (b as any).short_reason as string | undefined
  const income = (b as any).income as string | number | undefined

  return (
    <div className="rounded-3xl bg-white/5 p-3 w-full">
      <div className="flex items-start gap-3 w-full">
        {!performanceMode && (
          <img
            src={b.url}
            alt=""
            className="w-16 h-16 rounded-2xl object-cover bg-white/5 shrink-0 mt-[5px]"
            loading="lazy"
          />
        )}

        <div className="min-w-0 flex-1">
          <div className="font-medium truncate">{b.name_banner}</div>
          <div className="text-sm text-white/60 truncate">{b.id_banner}</div>

          <div className="mt-2">
            <div className={"inline-flex px-2 py-1 rounded-xl text-sm " + (isOff ? "bg-red-500/15 text-red-200" : "bg-emerald-500/15 text-emerald-200")}>
              {isOff ? "выключен" : "включен"}
            </div>
          </div>
        </div>

        <button
          className="rounded-2xl chip p-2 shrink-0"
          title="Действия"
          onClick={() => showToast("Пока заглушка: Включить всё и добавить в исключения")}
        >
          <IconDots className="h-5 w-5" />
        </button>
      </div>

      {/* Причина — на всю ширину, по дефолту закрыта */}
      <div className="mt-3 w-full">
        <button
          onClick={() => setReasonOpen(v => !v)}
          className="w-full rounded-2xl bg-white/5 p-3 text-left"
        >
          <div className="text-xs text-white/50 mb-1">Причина</div>
          <div className="text-sm whitespace-pre-wrap break-words">
            {reasonOpen ? (b.reason || "-") : (shortReason || b.reason || "-")}
          </div>
        </button>
      </div>

      {/* Метрики — на всю ширину, по дефолту закрыта */}
      <div className="mt-2 w-full">
        <button
          onClick={() => setStatsOpen(v => !v)}
          className="w-full rounded-2xl bg-white/5 p-3 text-left"
        >
          {!statsOpen ? (
            <div className="flex items-center justify-between gap-3 text-sm">
              <div className="truncate">
                {isOff ? `Расход: ${b.spent_all_time}` : `Доход: ${income ?? 0}`}
              </div>
              <div className="shrink-0 text-white/80">
                Цена результата: {b.cpa_all_time}
              </div>
            </div>
          ) : (
            <div className="space-y-1 text-sm">
              <div className="flex items-center justify-between gap-3">
                <div>Расход: {b.spent_all_time}</div>
                <div>Доход: {income ?? 0}</div>
              </div>
              <div className="flex items-center justify-between gap-3">
                <div>Результат: {b.goals_all_time}</div>
                <div>Цена результата: {b.cpa_all_time}</div>
              </div>
              <div className="flex items-center justify-between gap-3">
                <div>Клики: {b.clicks_all_time}</div>
                <div>Цена клика: {b.cpc_all_time}</div>
              </div>
            </div>
          )}
        </button>
      </div>
    </div>
  )
}

export function HistoryTab({
  accounts,
  settings,
  onSaveSettings,
  showToast,
}: {
  accounts: AccountItem[]
  settings: SettingsFile
  onSaveSettings: (next: SettingsFile) => Promise<void> | void
  showToast: (msg: string) => void
}) {
  const hs = defaultHistorySettings(settings.history_settings)

  const [accountOpen, setAccountOpen] = useState(false)
  const [dateOpen, setDateOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)

  const [selectedAccId, setSelectedAccId] = useState<string>(() => accounts[0]?.id || "")
  const [date, setDate] = useState<string>(() => {
    const d = new Date()
    return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`
  })

  const [items, setItems] = useState<HistoryBanner[]>([])
  const [loading, setLoading] = useState(false)

  // если аккаунты подгрузились позже
  useEffect(() => {
    if (!selectedAccId && accounts[0]?.id) setSelectedAccId(accounts[0].id)
  }, [accounts, selectedAccId])

  useEffect(() => {
    if (!selectedAccId) return
    let alive = true
    ;(async () => {
      try {
        setLoading(true)
        const res = await api.getHistoryBanners(selectedAccId, date)
        if (!alive) return
        setItems(res.items as HistoryBanner[])
      } catch (e: any) {
        showToast(e?.message || "Ошибка истории")
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => { alive = false }
  }, [selectedAccId, date])

  const filtered = useMemo(() => {
    return items.filter(b => {
      const isOff = String(b.status).toLowerCase() === "off"
      const isOn = String(b.status).toLowerCase() === "on"
      if (isOff && !hs.show_disabled) return false
      if (isOn && !hs.show_enabled) return false
      return true
    })
  }, [items, hs.show_disabled, hs.show_enabled])

  const grouped = useMemo(() => {
    const m = new Map<string, HistoryBanner[]>()
    for (const b of filtered) {
      const k = bucketKey(b.daytime)
      const arr = m.get(k) || []
      arr.push(b)
      m.set(k, arr)
    }
    for (const [k, arr] of m.entries()) {
      arr.sort((a, b) => (a.daytime < b.daytime ? 1 : -1))
      m.set(k, arr)
    }
    const keys = Array.from(m.keys()).sort((a, b) => (a < b ? 1 : -1))
    return keys.map(k => ({ key: k, items: m.get(k)! }))
  }, [filtered])

  const selectedAcc = accounts.find(a => a.id === selectedAccId)

  const saveHS = async (patch: Partial<HistorySettings>) => {
    const nextHS = { ...defaultHistorySettings(settings.history_settings), ...patch }
    const next: SettingsFile = { ...settings, history_settings: nextHS }
    await onSaveSettings(next)
  }

  return (
    <div className="px-3 pb-24 pt-3">
      {/* второй бар НА ВСЮ ШИРИНУ */}
      <div className="sticky top-[55px] z-20 -mx-3 -mt-3">
        <div className="glass border-y border-white/10 px-3 py-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAccountOpen(true)}
              className="flex-1 min-w-0 rounded-2xl chip px-3 py-3 text-left"
              title={selectedAcc?.name || selectedAccId}
            >
              <div className="truncate text-sm">
                {selectedAcc?.name || selectedAccId || "Выбери кабинет"}
              </div>
            </button>

            <button
              onClick={() => setDateOpen(true)}
              className="rounded-2xl chip px-3 py-3 text-sm"
              title="Выбрать дату"
            >
              {formatDateRU(date)}
            </button>

            <button
              onClick={() => setSettingsOpen(true)}
              className="rounded-2xl chip p-3"
              aria-label="Настройки истории"
              title="Настройки истории"
            >
              <IconGear className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* контент */}
      <div className="mt-3 space-y-3">
        {loading && (
          <div className="rounded-2xl bg-white/5 p-3 text-sm text-white/60">Загрузка…</div>
        )}

        {!loading && grouped.length === 0 && (
          <div className="rounded-2xl bg-white/5 p-3 text-sm text-white/60">
            За эту дату записей нет.
          </div>
        )}

        {grouped.map(g => {
          const timeLabel = pickTimeFromBucketKey(g.key) // только HH:mm

          return (
            <div key={g.key} className="rounded-3xl bg-white/5 p-3 w-full">
              <div className="flex items-center justify-between mb-2">
                {/* Только время, крупнее/жирнее */}
                <div className="text-base font-semibold text-white/90">{timeLabel}</div>

                <button
                  className="rounded-2xl chip p-2"
                  title="Действия"
                  onClick={() => showToast("Пока заглушка: действие группы")}
                >
                  <IconDots className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-2 w-full">
                {g.items.map(b => (
                  <BannerCard
                    key={`${b.id_banner}_${b.daytime}`}
                    b={b}
                    performanceMode={hs.performance_mode}
                    showToast={showToast}
                  />
                ))}
              </div>
            </div>
          )
        })}
      </div>

      {/* выбор кабинета */}
      <Sheet open={accountOpen} onClose={() => setAccountOpen(false)} title="Выбери кабинет">
        <div className="space-y-2">
          {accounts.map(a => (
            <button
              key={a.id}
              onClick={() => { setSelectedAccId(a.id); setAccountOpen(false) }}
              className={"w-full text-left rounded-2xl px-3 py-3 " + (a.id === selectedAccId ? "bg-white/15" : "chip")}
            >
              <div className="font-medium">{a.name || a.id}</div>
              <div className="text-sm text-white/50">id: {a.id}</div>
            </button>
          ))}
          {accounts.length === 0 && (
            <div className="text-sm text-white/60">Кабинетов нет</div>
          )}
        </div>
      </Sheet>

      {/* выбор даты */}
      <Modal
        open={dateOpen}
        onClose={() => setDateOpen(false)}
        title="Выбери дату"
        footer={
          <div className="flex gap-2">
            <button className="flex-1 rounded-2xl chip py-3" onClick={() => setDateOpen(false)}>Закрыть</button>
            <button className="flex-1 rounded-2xl bg-white/15 py-3" onClick={() => setDateOpen(false)}>
              Ок
            </button>
          </div>
        }
      >
        <input
          type="date"
          className="w-full rounded-2xl chip bg-transparent px-4 py-3 outline-none"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </Modal>

      {/* настройки истории */}
      <Sheet open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Настройка историй">
        <div className="space-y-3">
          <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
            <div className="text-sm">
              <div className="font-medium">Производительный режим</div>
              <div className="text-white/50 text-xs">Если включено — убираются превью</div>
            </div>
            <input
              type="checkbox"
              checked={hs.performance_mode}
              onChange={(e) => saveHS({ performance_mode: e.target.checked })}
            />
          </label>

          <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
            <div className="text-sm font-medium">Показывать отключенные</div>
            <input
              type="checkbox"
              checked={hs.show_disabled}
              onChange={(e) => saveHS({ show_disabled: e.target.checked })}
            />
          </label>

          <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-3">
            <div className="text-sm font-medium">Показывать включенные</div>
            <input
              type="checkbox"
              checked={hs.show_enabled}
              onChange={(e) => saveHS({ show_enabled: e.target.checked })}
            />
          </label>
        </div>
      </Sheet>
    </div>
  )
}
