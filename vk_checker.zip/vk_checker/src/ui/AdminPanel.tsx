// src/ui/AdminPanel.tsx
import { Sheet } from './Sheet'
import { api } from '../lib/api'
import { useState } from 'react'
import { Toast } from './Toast'
import { Modal } from './Modal'

export function AdminPanel({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const [q, setQ] = useState('')
  const [users, setUsers] = useState<any[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [filtersJson, setFiltersJson] = useState('')

  const [confirmUser, setConfirmUser] = useState<{
    tg_id: string
    tg_username?: string
  } | null>(null)

  // локальный Toast
  const [toast, setToast] = useState<{ show: boolean; msg: string }>({ show: false, msg: '' })
  const showToast = (msg: string) => {
    setToast({ show: true, msg })
    setTimeout(() => setToast({ show: false, msg: '' }), 1800)
  }

  const resetState = () => {
    setQ('')
    setUsers([])
    setSelected(null)
    setFiltersJson('')
  }

  const handleClose = () => {
    resetState()
    onClose()
  }

  const search = async () => {
    try {
      const res = await api.adminListUsers(q)
      setUsers(res.users || [])
      if ((res.users || []).length === 0) showToast('Нет пользователей')
    } catch (e: any) {
      console.error(e)
      showToast(e?.message || 'Ошибка поиска')
    }
  }

  const loadFilters = async (tg_id: string) => {
    try {
      const res = await api.adminGetUserFilters(tg_id)
      setSelected(tg_id)
      setFiltersJson(JSON.stringify(res.filters || {}, null, 2))
    } catch (e: any) {
      console.error(e)
      showToast(e?.message || 'Ошибка загрузки фильтров')
    }
  }

  const save = async () => {
    if (!selected) return
    let parsed: any
    try {
      parsed = JSON.parse(filtersJson)
    } catch (e) {
      showToast('Некорректный JSON')
      return
    }
    try {
      await api.adminSaveUserFilters(selected, parsed)
      showToast('Сохранено')
    } catch (e: any) {
      console.error(e)
      showToast(e?.message || 'Ошибка сохранения')
    }
  }

  const impersonate = async (tg_id: string) => {
    try {
      const r = await api.adminImpersonate(tg_id)
      if (r.jwt) {
        // сохраняем текущий (админский) JWT
        const current = localStorage.getItem('vk_checker_jwt')
        if (current && !localStorage.getItem('vk_checker_admin_jwt')) {
          localStorage.setItem('vk_checker_admin_jwt', current)
        }
      
        // подменяем JWT на пользовательский
        localStorage.setItem('vk_checker_jwt', r.jwt)
      
        showToast('Вход выполнен')
        setTimeout(() => window.location.reload(), 300)
      } else {
        showToast('Токен не получен')
      }
    } catch (e: any) {
      console.error(e)
      showToast(e?.message || 'Ошибка при входе от имени')
    }
  }

  return (
    <>
      <Toast show={toast.show} message={toast.msg} />
      <Sheet open={open} onClose={handleClose} title="Админ-панель">
        <div className="space-y-3">

          <div className="flex gap-2">
            <input
              className="flex-1 rounded-2xl chip px-3 py-2"
              placeholder="tg_id / username"
              value={q}
              onChange={e => setQ(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') search() }}
            />
            <button className="rounded-2xl bg-white/15 px-4" onClick={search}>
              Найти
            </button>
          </div>

          <div className="space-y-2 max-h-60 overflow-auto">
            {users.map(u => (
              <div key={u.tg_id} className="rounded-2xl bg-white/5 p-3 flex justify-between">
                <div>
                  <div className="font-medium">{u.tg_username || '—'}</div>
                  <div className="text-xs text-white/60">{u.tg_id}</div>
                </div>
                <div className="flex gap-2">
                  <button className="chip px-3 py-1" onClick={() => loadFilters(u.tg_id)}>
                    Фильтры
                  </button>
                  <button
                    className="chip px-3 py-1"
                    onClick={() => setConfirmUser({ tg_id: u.tg_id, tg_username: u.tg_username })}
                  >
                    Войти
                  </button>
                </div>
              </div>
            ))}
          </div>

          {selected && (
            <>
              <div className="text-sm font-medium">Фильтры пользователя</div>
              <textarea
                className="w-full rounded-2xl bg-white/5 p-3 font-mono text-xs"
                rows={10}
                value={filtersJson}
                onChange={e => setFiltersJson(e.target.value)}
              />
              <div className="flex gap-2">
                <button className="rounded-2xl chip py-2" onClick={() => { setSelected(null); setFiltersJson('') }}>
                  Закрыть
                </button>
                <button className="rounded-2xl bg-white/15 py-2" onClick={save}>
                  Сохранить
                </button>
              </div>
            </>
          )}

        </div>
      </Sheet>
      <Modal
        open={!!confirmUser}
        onClose={() => setConfirmUser(null)}
        title="Подтвердите вход"
        footer={
          <div className="flex gap-2">
            <button
              className="flex-1 rounded-2xl chip py-3"
              onClick={() => setConfirmUser(null)}
            >
              Отмена
            </button>
            <button
              className="flex-1 rounded-2xl bg-white/15 py-3"
              onClick={() => {
                if (!confirmUser) return
                impersonate(confirmUser.tg_id)
                setConfirmUser(null)
              }}
            >
              Войти
            </button>
          </div>
        }
      >
        <div className="text-sm text-white/80">
          Вы уверены, что хотите войти от имени:
        </div>
      
        <div className="rounded-2xl bg-white/5 p-3">
          <div className="font-medium">
            {confirmUser?.tg_username || 'Без username'}
          </div>
          <div className="text-xs text-white/60">
            {confirmUser?.tg_id}
          </div>
        </div>
      </Modal>
    </>
  )
}
