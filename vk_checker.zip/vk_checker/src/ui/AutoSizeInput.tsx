import React, { useLayoutEffect, useRef, useState } from "react";

export function AutoSizeInput({
  value,
  onChange,
  className,
  minCh = 2,
  maxPx = 160,
  inputMode = "numeric",
  placeholder,
}: {
  value: string | number;
  onChange: (v: string) => void;
  className?: string;
  minCh?: number;
  maxPx?: number;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
  placeholder?: string;
}) {
  const spanRef = useRef<HTMLSpanElement | null>(null);
  const [w, setW] = useState<number>(0);

  const text = String(value ?? "");
  const measureText = text.length ? text : (placeholder || "0");

  useLayoutEffect(() => {
    const el = spanRef.current;
    if (!el) return;
    const width = el.getBoundingClientRect().width;
    // + немного паддинга, чтобы курсор не упирался
    const px = Math.min(maxPx, Math.max(minCh * 10, Math.ceil(width) + 18));
    setW(px);
  }, [measureText, minCh, maxPx]);

  return (
    <>
      <span
        ref={spanRef}
        className={"absolute -left-[9999px] -top-[9999px] whitespace-pre " + (className || "")}
        style={{ paddingLeft: 0, paddingRight: 0 }}
      >
        {measureText}
      </span>

      <input
        style={{ width: w ? `${w}px` : undefined }}
        className={className}
        inputMode={inputMode}
        value={value as any}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </>
  );
}
