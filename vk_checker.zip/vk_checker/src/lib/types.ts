export type Op = 'LT'|'LTE'|'GT'|'GTE'|'EQ'
export type PeriodType = 'ALL_TIME'|'TODAY'|'YESTERDAY'|'LAST_N_DAYS'

export type Period = { type: PeriodType; n?: number }

type CondBase = { cid?: string }

export type RootCondition =
  | (CondBase & { type:'SPENT'; period: Period; op: Op; valueRub: number })
  | (CondBase & { type:'TARGET_ACTION'; target: 'BOT_MESSAGE'|'SITE'|'LEADFORM'|'APP' })
  | (CondBase & {
      type:'INCOME';
      period: Period;
      mode:'HAS'|'HAS_NOT'|'COMPARE'|'COMPARE_SPEND';
      op?: Op;
      value?: number;
      spendPeriod?: Period;
      multiplier?: number;
    })

export type AccountsScope =
  | { mode:'ALL' }
  | { mode:'SELECTED'; selected: string[] } // account ids

export type Metric = 'CLICK_COST'|'RESULT_COST'|'CLICKS'|'RESULTS'

export type FilterRule = { type:'COST_RULE'; spentRub:number; metric:Metric; op:Op; value:number }
export type ActionState = 'ENABLE'|'DISABLE'|'NOOP'
export type Action = { type:'SET_STATE'; state: ActionState }

export type NestedFilter = {
  type:'FILTER'
  mode:'ALL'|'ANY'
  rules: FilterRule[]
  action: Action
}

export type RootNode = {
  type:'ROOT'
  accountsScope: AccountsScope
  conditions: RootCondition[]
  child: NestedFilter | Action
}

export type FilterTemplate = { id:string; name:string; root: RootNode; priority?: 1|2|3|4|5 }
export type FiltersFile = { version:number; templates: FilterTemplate[] }

export type HistorySettings = {
  performance_mode: boolean
  show_disabled: boolean
  show_enabled: boolean
}

export type HistoryBanner = {
  daytime: string
  id_banner: string
  name_banner: string
  url: string
  reason?: string
  status: 'off' | 'on' | string
  spent_all_time?: string
  goals_all_time?: string
  cpa_all_time?: string
  clicks_all_time?: string
  cpc_all_time?: string
}

export type SettingsFile = {
  ignore_manual_enabled_ads?: boolean

  limit_disabled_banners_20?: boolean
  only_spent_all_time_lte_5000?: boolean

  tg_notify_enabled?: boolean
  tg_notify_every_min?: number

  history_settings?: HistorySettings
}

export type ListFile = {
  campaign_ids: string[]
  banner_ids: string[]
}

export type AccountItem = { token:string; name:string; id:string }

export type BootstrapResponse = {
  jwt: string
  user: {
    tg_id: string
    tg_username: string
    accounts: AccountItem[]
    filters: FiltersFile
    settings: SettingsFile
    income_path?: string
  }
}


