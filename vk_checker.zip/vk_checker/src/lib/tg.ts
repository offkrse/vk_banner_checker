export function getInitData(): string {
  const tg = (window as any).__tg || ((window as any).Telegram && (window as any).Telegram.WebApp)
  return tg?.initData || ''
}

export function haptic(type: 'light'|'medium'|'heavy' = 'light') {
  const tg = (window as any).__tg
  tg?.HapticFeedback?.impactOccurred?.(type)
}
