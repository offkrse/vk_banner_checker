import type { BootstrapResponse, FiltersFile, SettingsFile, ListFile } from './types'
const LS_JWT = 'vk_checker_jwt'

function getJwt() { return localStorage.getItem(LS_JWT) || '' }
function setJwt(v: string) { localStorage.setItem(LS_JWT, v) }

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const jwt = getJwt()
  const headers: Record<string,string> = {
    'Content-Type': 'application/json',
    ...(init?.headers as any),
  }
  if (jwt) headers['Authorization'] = `Bearer ${jwt}`

  const res = await fetch(path, { ...init, headers })
  if (!res.ok) {
    const t = await res.text().catch(()=> '')
    throw new Error(t || `HTTP ${res.status}`)
  }
  return res.json() as Promise<T>
}

export const api = {
  async bootstrap(initData: string): Promise<BootstrapResponse> {
    const res = await fetch('/vk_checker_v4/api/bootstrap', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ initData }),
    })
    if (!res.ok) throw new Error(await res.text().catch(()=> 'bootstrap failed'))
    const data = (await res.json()) as BootstrapResponse
    setJwt(data.jwt)
    return data
  },

  async adminListUsers(q: string) {
    return http<{ users: { tg_id: string; tg_username?: string; accounts?: any[] }[] }>(
      `/vk_checker_v4/api/admin/users?q=${encodeURIComponent(q)}`
    )
  },
  
  async adminGetUserFilters(tg_id: string) {
    return http(`/vk_checker_v4/api/admin/users/${encodeURIComponent(tg_id)}/filters`)
  },
  
  async adminSaveUserFilters(tg_id: string, filters: any) {
    return http(`/vk_checker_v4/api/admin/users/${encodeURIComponent(tg_id)}/filters`, {
      method: "PUT",
      body: JSON.stringify(filters),
    })
  },
  
  async adminImpersonate(tg_id: string) {
    return http(`/vk_checker_v4/api/admin/impersonate`, {
      method: "POST",
      body: JSON.stringify({ tg_id }),
    })
  },

  async setIncomePath(sub1: string) {
    return http<{ok:boolean; income_path:string}>('/vk_checker_v4/api/income-path', {
      method: 'PUT',
      body: JSON.stringify({ sub1 }),
    })
  },

  async state() {
    return http<{accounts:any; filters:any; settings:any}>('/vk_checker_v4/api/state')
  },

  async validateToken(token: string) {
    return http<{id:string; client_name:string; email?:string}>('/vk_checker_v4/api/accounts/validate', {
      method:'POST',
      body: JSON.stringify({ token }),
    })
  },

  async confirmToken(token: string, id: string, name: string) {
    return http<{accounts:any}>('/vk_checker_v4/api/accounts/confirm', {
      method:'POST',
      body: JSON.stringify({ token, id, name }),
    })
  },

  async getList(kind: 'white'|'black'): Promise<ListFile> {
    return http<ListFile>(`/vk_checker_v4/api/lists/${kind}`)
  },
  async saveList(kind: 'white'|'black', data: ListFile) {
    return http<{ok:boolean}>(`/vk_checker_v4/api/lists/${kind}`, {
      method:'PUT',
      body: JSON.stringify(data),
    })
  },

  async getFilters(): Promise<FiltersFile> {
    return http<FiltersFile>('/vk_checker_v4/api/filters')
  },
  async saveFilters(filters: FiltersFile) {
    return http<{ok:boolean}>('/vk_checker_v4/api/filters', { method:'PUT', body: JSON.stringify(filters) })
  },

  async getSettings(): Promise<SettingsFile> {
    return http<SettingsFile>('/vk_checker_v4/api/settings')
  },
  async saveSettings(settings: SettingsFile) {
    return http<{ok:boolean}>('/vk_checker_v4/api/settings', { method:'PUT', body: JSON.stringify(settings) })
  },
  async getHistoryBanners(accountId: string, date: string) {
    return http<{ items: any[] }>(
      `/vk_checker_v4/api/history/banners?account_id=${encodeURIComponent(accountId)}&date=${encodeURIComponent(date)}`
    )
  },
}
